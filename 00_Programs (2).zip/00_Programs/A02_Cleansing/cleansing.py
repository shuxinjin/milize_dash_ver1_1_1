# -*- coding: utf-8 -*-
'''
Name        : cleansing.py
Purpose     : テキストファイルのクレンジング
Created Date: 2018.08.08
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.08.08
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''

import re
import sys
sys.path.append('../A50_Config')
sys.path.append('../A90_utils')

import traceback

from   A50_Config.config_roll import file_names
from   A90_utils.m_txtm_base  import m_txtm_base
from   A90_utils.localIO      import create_outdir
from   A90_utils.localIO      import is_existing
from   .config_cln            import col_names
from   .broker_cln            import cln_by_brokerID
from   .get_report_items      import load_reports
    
class cleansing(m_txtm_base):

    _log_dir = '../../log/current_roll/cln'
    _log_prefix = 'cln_'
    _encoding = file_names.FILE_ENCODING
        
    def _read_file(self, in_file, out_file, broker_id):
        '''
        1個のファイルから読み取り
        '''
        try:

            self._log('Read : {}'.format(in_file))

            report_text = ''
            with open(in_file, encoding='utf-8') as f, open(out_file, 'w', encoding = 'utf-8') as o:
                for line in f:
                    #if isNotEmpty(line):
                    report_text += line
                cleansed_text = cln_by_brokerID(broker_id, report_text)
                #print(cleansed_text)
                print(cleansed_text, file = o)
                #if not checked_any:
                #    self._log('Warnings:  cleansing key word not found in {}'.format(in_file))
                
        except Exception  as e:
            info = ['error in {}:'.format(in_file)]
            info.append(str(e))
            info.extend(traceback.format_tb(e.__traceback__))
            self._log(info, file_info = self.__class__.__name__, error_flag = True)
            pass
            
    def main(self, report_broker_file):
    
        # レポート一覧取得
        reports = load_reports(report_broker_file, self._encoding)
        for _, row in reports.iterrows():
            in_file = row[col_names.FULL_PATH]
            broker_id = row[col_names.BROKER_ID]
            out_file = re.sub(file_names.TEXT_HOME_DIR, file_names.CLNS_DIR, in_file)
            
            if in_file == out_file:
                self._log('error in {}:'.format(in_file))
                break
            if not is_existing(out_file):
                create_outdir(out_file)
                self._read_file(in_file, out_file, broker_id)
