# -*- coding: utf-8 -*-
'''
Name        : config_cln.py
Version     : 2.0
Purpose     : クレンジング用の定数のまとめ
Created Date: 2018.08.08
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.08.08
Updated by  : Wenfeng Huang (MILIZE Inc.)

'''

class col_names(object):
    SEC_CODE        = 'sec_code'
    SECTOR_CODE     = 'sector_code' #業種コード
    REPORT_ID       = 'report_id' # レポートID
    REPORT_DATE     = 'report_date' # レポート日付
    JP_SEC_CLASS    = 'jpn_sec_class' # 会計基準区分
    BROKER_ID       = 'broker_id' # 発行体ID
    BROKER_NAME     = 'broker_name' # 発行体名
    SETTLEMENT_TERM = 'settlement_term' # 決算期
    FULL_PATH       = 'full_path'
    PDF_PATH        = 'pdf_path'

class brokers(object):
    '''
    IFIS DBにある発行体
    '''
    brokers = { \
                     0 : [ 1, 'ゴールドマン･サックス証券','関東財務局長[\s]*\(金商\)[\s]*第[\s]*69[\s]*号'], \
                     1 : [18, '岡三証券','関東財務局長[\s]*\(金商\)[\s]*第[\s]*53[\s]*号'], \
                     2 : [22, '野村證券','関東財務局長[\s]*\(金商\)[\s]*第[\s]*142[\s]*号'], \
                     3 : [23, '大和証券グループ','関東財務局長[\s]*\(金商\)[\s]*第[\s]*108[\s]*号'], \
                     4 : [28, 'みずほ証券','関東財務局長[\s]*\(金商\)[\s]*第[\s]*94[\s]*号'], \
                     5 : [30, 'いちよし経済研究所','関東財務局長[\s]*\(金商\)[\s]*第[\s]*24[\s]*号'], \
                     6 : [34, '三菱UFJモルガン・スタンレー証券','関東財務局長[\s]*\(金商\)[\s]*第[\s]*2336[\s]*号'], \
                     7 : [46, 'バークレイズ証券','関東財務局長[\s]*\(金商\)[\s]*第[\s]*143[\s]*号'], \
                     8 : [60, '東海東京調査センター','東海財務局長[\s]*\(金商\)[\s]*第[\s]*140[\s]*号'], \
                     9 : [61, '岩井コスモ証券','近畿財務局長[\s]*\(金商\)[\s]*第[\s]*15[\s]*号'], \
                    10 : [97, 'SMBC日興証券','関東財務局長[\s]*\(金商\)[\s]*第[\s]*2251[\s]*号'], \
                    11 : [10, 'UBS証券','関東財務局長[\s]*\(金商\)[\s]*第[\s]*2633[\s]*号'], \
                    12 : [ 4, 'モルガン・スタンレーMUFG証券', 'Morgan Stanley Research', 'モルガン・スタンレーMUFG証券'], \
                    13 : [29, 'クレディ・スイス証券','関東財務局長[\s]*\(金商\)[\s]*第[\s]*66[\s]*号'], \
                    14 : [ 7, 'メリルリンチ日本証券','関東財務局長[\s]*\(金商\)[\s]*第[\s]*186[\s]*号'], \
                    15 : [15, 'JPモルガン証券','関東財務局長[\s]*\(金商\)[\s]*第[\s]*82[\s]*号'], \
                    16 : [21, 'ドイツ証券','関東財務局長[\s]*\(金商\)[\s]*第[\s]*117[\s]*号', '\.db\.com'], \
                    17 : [56, 'TIW','ティー・アイ・ダヴリュ', 'TIW[\s]*企業ウォッチ'], \
                    18 : [ 6, 'マッコーリーキャピタル証券','関東財務局長[\s]*\(金商\)[\s]*第[\s]*231[\s]*号','関東財務局長[\s]*\(金商\)[\s]*第[\s]*2769[\s]*号','マッコーリーキャピタル証券'], \
                    19 : [24, 'BNPパリバ証券','関東財務局長[\s]*\(金商\)[\s]*第[\s]*2521[\s]*号','関東財務局長[\s]*\(金商\)[\s]*第[\s]*228[\s]*号'], \
                    20 : [26, 'シティグループ証券','関東財務局長[\s]*\(金商\)[\s]*第[\s]*130[\s]*号'], \
                    21 : [44, 'みずほインベスターズ証券','みずほインベスターズ証券'], \
                    22 : [90, 'ジェフリーズ証券','ジェフリーズ証券'], \
                    }

    broker_dic = {
                      1 : 'GoldmanSachs', \
                     18 : 'Okasan', \
                     22 : 'Nomura' , \
                     23 : 'Daiwa' , \
                     28 : 'Mizuho' , \
                     30 : 'Ichiyoshi' , \
                     34 : 'MUFJ_Morgan_Stanley', \
                     46 : 'Barclays', \
                     60 : 'TokaiTokyo', \
                     61 : 'Iwaicosmo', \
                     97 : 'SMBCNikko', \
                     10 : 'UBS', \
                      4 : 'Morgan_Stanley_MUFG', \
                     29 : 'Credit_Suisse', \
                      7 : 'Merrill_Lynch', \
                     15 : 'JPMorgan', \
                     21 : 'Deutsche', \
                     56 : 'TIW', \
                      6 : 'Macquarie', \
                     24 : 'BNPparibas', \
                     26 : 'Citi', \
                     44 : 'Mizuho_Investors', \
                     90 : 'Jeffreys', \
                  }
