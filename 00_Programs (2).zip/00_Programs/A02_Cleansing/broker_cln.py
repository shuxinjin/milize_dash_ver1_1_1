# -*- coding: utf-8 -*-
'''
Name        : broker_cln.py
Purpose     : 証券会社ごとクレンジング実施モジュール
Created Date: 2018.08.08
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.08.08
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''

import re
import unicodedata

from .config_cln  import brokers
              
def cln_by_brokerID(broker_id, text):
    
    if broker_id in brokers.broker_dic:
        cln_cls = globals()['cln_{}'.format(brokers.broker_dic[broker_id])]
        return cln_cls(text).cleanse()
    else:
        return cln_common(text).cleanse()

class cln_common(object):
    
    # 除外文字列
    _excep_Str = '|'.join(['〒', \
                  '\A[\s]*[※注][\s\d]+', \
                  '[:·]{3,}', \
                  '[\(\s]*出所[\s\)]*', \
                  '\(\s*注[\s\d]*\)', \
                  'ディスクロージャー', \
                  ])
    
    _block_sep = '\n\n' # ブロック分離用文字列
    _min_len = 25
    
    def _filter(self, x):
        #電子メール電話番号など除去
        y = re.sub('[\d\sa-zA-Z\(\)\+\-\@\.]', '', x)
        return len(y) >=self. _min_len

    def _replace(self, x):
        return re.sub('[\s]+$', '\n', x)

    def _remove_extra_spaces(self, s):
        s = re.sub('[ 　]+', ' ', s)
        blocks = ''.join(('\u4E00-\u9FFF',  # CJK UNIFIED IDEOGRAPHS
                          '\u3040-\u309F',  # HIRAGANA
                          '\u30A0-\u30FF',  # KATAKANA
                          '\u3000-\u303F',  # CJK SYMBOLS AND PUNCTUATION
                          '\uFF00-\uFFEF'   # HALFWIDTH AND FULLWIDTH FORMS
                          ))
        basic_latin = '\u0000-\u007F'
    
        def remove_space_between(cls1, cls2, s):
            p = re.compile('([{}]) ([{}])'.format(cls1, cls2))
            while p.search(s):
                s = p.sub(r'\1\2', s)
            return s
    
        s = remove_space_between(blocks, blocks, s)
        s = remove_space_between(blocks, basic_latin, s)
        s = remove_space_between(basic_latin, blocks, s)
        return s
        
    def _normalize(self, text):
        s = unicodedata.normalize('NFKC', text.split('\f')[0])
        self._text = self._remove_extra_spaces(s)
        
    def __init__(self, text):
        self._normalize(text)
        
    def cleanse(self):
        result_text = []
        blocks = self._text.split(self._block_sep)
        #i = 0
        for block in blocks:
#            print(block)
#            print('~~~~~~~~~~~~~~~~~')
#            print(self._excep_Str)
            if re.search(self._excep_Str, block) is None:
                #print(block)
                #print('-------block-------{}'.format(i))
                #print(block)
                #i += 1
                segs = block.split('\n')
                #print(segs)
                #if re.search(self._excep_Str, segs[0]) is not None:
                #    print('Ignore')
                #    print(re.search(self._excep_Str, segs[0]).group())
                if len(segs) >= 1:
                    #print('::::', segs[0])
                    sentence = ''
                    for seg in segs[1:-1]:
                        if re.search(self._excep_Str, seg) is not None:
                            #print(seg)
                            break
                        if self._filter(seg):
                            #sentence += re.sub('[^\da-zA-Z]+[\s]+$', '\n', seg)
                            sentence += seg
                            #print('seg = ', seg)
                            #print(re.search(self._excep_Str, seg))
                    if sentence != '' or self._filter(segs[0]):
                        #print('segs0 = ', segs[0])
                        #print('segs-1= ', segs[-1])
                        sentence = self._replace(segs[0]) + sentence
                        if len(segs) > 1:
                            sentence += self._replace(segs[-1])
                            #print(segs[-1])
                        #print('====={}====='.format(sentence))
                        #print('+++{}++++'.format(re.sub('[\s　]$', '\n', sentence)))
                        result_text.append(sentence)
        #print('JJJJJJJJJJJJJJJJJJ')
        #print(result_text)
        #print(self._excep_Str)
        return '\n'.join(result_text)
        
class cln_GoldmanSachs(cln_common):
    '''
    ゴールドマン･サックス証券
    '''
    _excep_Str = '|'.join(['〒', \
                  '\A[\s]*[※注][\s\d]+', \
                  '[:·]{3,}', \
                  '[\(\s]*出所[\s\)]*', \
                  '[\(\s]*注[\s\d]*[\s\):]+', \
                  'ディスクロージャー', \
                  '本資料に記載される企業と業務', \
                  '所:.*ゴールドマン', \
                  ])
    
    pass
    
class cln_Okasan(cln_common):
    '''
    岡三証券
    '''
    _excep_Str = '|'.join(['〒', \
                           '\A[\(\s]*[※注][\s\d:\)]+', \
                           '[:·]{3,}', \
                           '[\(\s]*出所[\s\)]*', \
                           'ディスクロージャー', \
                           '\A\s*\*', \
                           '(?i)OKASAN SECURITIES',
                           ])
    def _normalize(self, text):
        s = unicodedata.normalize('NFKC', text.split('\f')[0])
        s = self._remove_extra_spaces(s)
        self._text = re.sub('[^\s]\n', '', s)
        #print(self._text)
        
    def _replace(self, x):
        return re.sub('\A\s*発行日.*$|OKASAN.*\n', '', x)

class cln_Nomura(cln_common):
    '''
    野村證券
    '''
    # 除外文字列
    _excep_Str = '|'.join(['(?i)Appendix[\s]+', \
                           '(?i)\A[\s]+Nomura[\s]*\|', \
                           '(?i)(\A|\s)+Equity[\s:]+', \
                           '〒', \
                           '\A[\s\(]*出所', \
                           '\A[\s]*[※注][\s\d:]+', \
                          ])
        
class cln_Daiwa(cln_common):
    '''
    大和証券グループ
    '''
    _excep_Str = 'このレポートは|〒|\A[\s]*[※注][\s\d]+|出所[：:]|Credit Memorandum'

    def _normalize(self, text):
        s = unicodedata.normalize('NFKC', text.split('\f')[0])
        s = self._remove_extra_spaces(s)
        self._text = re.sub('[^\s]\n', '', s)
        #print(self._text)
    
class cln_Mizuho(cln_common):
    '''
    みずほ証券
    '''
    # 除外文字列
    _excep_Str = '|'.join(['\A[\s]*\*', \
                           '〒', \
                           '\A[\s]*[※注][\s\d]+', \
                           '出所：', \
                           '関する重要開示事項', \
                           ])
    # 改行キーワード
    _keywords = ['注目点', '投資判断とバリュエーション', '業績動向', 'カタリスト/リスク', '決算コメント']
    
    def _replace(self, x):
        if x in self._keywords:
            return x + '\n'
        else:
            return x
        
class cln_Ichiyoshi(cln_common):
    '''
    いちよし経済研究所
    '''
    _excep_Str = '|'.join(['〒',\
                  '\A[\s]*[※注][\s\d]+', \
                  '[:·]{3,}', \
                  '[\(\s]*出所[\s\)]*', \
                  '\(\s*注[\s\d]*\)', \
                  'ディスクロージャー', \
                  '企業コメント', \
                  '重要な注意事項', \
                  'コント.実施', \
                  '企業レポート', \
                  '新聞記事などの印象', \
                  ])
    
    def _normalize(self, text):
        s = unicodedata.normalize('NFKC', text.split('\f')[0])
        s = self._remove_extra_spaces(s)
        self._text = re.sub('[^\s]\n', '', s)
        
class cln_MUFJ_Morgan_Stanley(cln_common):
    '''
    三菱UFJモルガン・スタンレー証券
    '''
    # Finished
    _excep_Str = '|'.join(['〒',\
                  '\A[\s]*[※注][\s\d]+', \
                  '[:·]{3,}', \
                  '[\(\s]*出所[\s\)]*', \
                  '\(\s*注[\s\d]*\)', \
                  'ディスクロージャー', \
                  '本レポートおよび本レポート', \
                  '重要な注意事項', \
                  'MUMSS', \
                  ])
        
class cln_Barclays(cln_common):
    '''
    バークレイズ証券
    '''
    _excep_Str = '|'.join(['〒', \
                  '\A[\s]*[※注][\s\d]+', \
                  '[:·]{3,}', \
                  '[\(\s]*出所[\s\)]*', \
                  '\(\s*注[\s\d]*\)', \
                  'ディスクロージャー', \
                  'アナリスト宣誓及び重要な開示事項', \
                  'バークレイズ証券のアナリスト', \
                  ])
        
class cln_TokaiTokyo(cln_common):
    '''
    東海東京調査センター
    '''
    _excep_Str = '|'.join(['〒',\
                  '\A[\s]*[※注][\s\d]+', \
                  '[:·]{3,}', \
                  '[\(\s]*出所[\s\)]*', \
                  '\(\s*注[\s\d]*\)', \
                  'ディスクロージャー', \
                  'このレポート', \
                  '商品取引法に基づき', \
                  'お客様ご自身の判断', \
                  '投資成果がTOPIXに対して', \
                  '東海財務局長', \
                  '日本証券業協会、', \
                  '金融商品リスク等につい', \
                  '(.*東海東京調査センター.*)', \
                  ])
    

class cln_Iwaicosmo(cln_common):
    '''
    岩井コスモ証券
    '''
    _excep_Str = '|'.join(['〒',\
                  '\A[\s]*[※注][\s\d]+', \
                  '[:·]{3,}', \
                  '[\(\s]*出所[\s\)]*', \
                  '\(\s*注[\s\d]*\)', \
                  'ディスクロージャー', \
                  '本資料に掲載された意見、予測', \
                  '伸び率\s*営業利益\s*伸び率'
                  ])
    
    pass
        
class cln_SMBCNikko(cln_common):
    '''
    SMBC日興証券
    '''
    _excep_Str = '|'.join(['〒',\
                           '(?i)\A[\s]*SMBC日興証券', \
                           '\A[\s]*[※]', \
                           'SMBC NIKKO', \
                           '本レポートは、', \
                           '\A[\(\s]*[※注][\s\d:\)]+', \
                           '(.{2,4}益前期比){2,}',
                           '※注記', \
                           '日興証券およびその関連会社は'
                           ])
    def _replace(self, x):
        return re.sub('[\s]+$|.*\(\s*[1-9]\d{3}\s*\)\s*[：:]$', '', x)

class cln_UBS(cln_common):
    '''
    UBS証券
    '''
    _excep_Str = '|'.join(['〒',\
                  '\A[\s]*[※注][\s\d]+', \
                  '[:·]{3,}', \
                  '[\(\s]*出所[\s\)]*', \
                  '\(\s*注[\s\d]*\)', \
                  'ディスクロージャー', \
                  ':会社資料、', \
                  'バリュエーションはその年', \
                  ])

class cln_Morgan_Stanley_MUFG(cln_common):
    '''
    モルガン・スタンレーMUFG証券
    '''
    _excep_Str = '|'.join(['(?i)[\s]+Stanley', \
                           'モルガン', \
                           'スタンレー', \
                           '\A\+{2,}', \
                           '〒', \
                           'アナリストによる証明', \
                           ])
    
class cln_Credit_Suisse(cln_common):
    '''
    クレディ・スイス証券
    '''
    _excep_Str = '|'.join(['〒', \
                           '\A[\s]*[※注][\s\d]+|[:·]{3,}', \
                           '[\(\s]*出所[\s\)]*', \
                           '\(\s*注[\s\d]*\)', \
                           'ディスクロージャー', \
                           '\A_', \
                           '投資評価は各アナリスト', \
                           '[\d\.%\(\)]{25,}', \
                           '\A[図表]+[\d:]+', \
                           ])
    pass

class cln_Merrill_Lynch(cln_common):
    '''
    メリルリンチ日本証券
    '''
    pass
        
class cln_JPMorgan(cln_common):
    '''
    JPモルガン証券
    '''
    _excep_Str = '|'.join(['〒', \
                  '\A[\s]*[※注][\s\d]+', \
                  '[:·]{3,}', \
                  '[\(\s]*出所[\s\)]*', \
                  '\(\s*注[\s\d]*\)', \
                  'ディスクロージャー', \
                  '注意\s*:', \
                  ])
        
class cln_Deutsche(cln_common):
    '''
    ドイツ証券
    '''
    _excep_Str = '|'.join(['〒', \
                           '\A[\(\s]*[※注][\s\d:\)]+', \
                           '[:·]{3,}', \
                           '[\(\s]*出所[\s\)]*', \
                           'ディスクロージャー', \
                           '示された見解は、', \
                           '\A_', \
                           '[\d\.%\(\)]{25,}', \
                           ])

class cln_TIW(cln_common):
    '''
    TIW
    '''
    _excep_Str = '|'.join(['〒', \
                  '\A[\s]*[※注][\s\d]+', \
                  '[:·]{3,}', \
                  '[\(\s]*出所[\s\)]*', \
                  '\(\s*注[\s\d]*\)', \
                  'ディスクロージャー', \
                  '利益相反に関する開示事項', \
                  '掲載された情報・意見', \
                  ])

class cln_Macquarie(cln_common):
    '''
    マッコーリーキャピタル証券
    '''
    
    pass

class cln_BNPparibas(cln_common):
    '''
    BNPパリバ証券
    '''
    _excep_Str = '〒|\A[\s]*[※注][\s\d]+|[:·]{3,}|[\(\s]*出所[\s\)]*|\(\s*注[\s\d]*\)|ディスクロージャー'
    # todo

class cln_Citi(cln_common):
    '''
    シティグループ証券
    '''
    pass

class cln_Mizuho_Investors(cln_common):
    '''
    みずほインベスターズ証券（廃止）
    '''
    pass
        
class cln_Jeffreys(cln_common):
    '''
     ジェフリーズ証券
    '''
    pass
