# -*- coding: utf-8 -*-
'''
Name        : broker_items.py
Purpose     : 証券会社ごとの項目取得
Created Date: 2018.08.08
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.08.08
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''

import re
import numpy       as     np

from .config_cln import brokers
              
def get_item_by_brokerID(broker_id, text):
    
    if broker_id in brokers.broker_dic:
        item_cls = globals()['Item_{}'.format(brokers.broker_dic[broker_id])]
        return item_cls(text).items()
    else:
        return Item_common(text).items()

class Item_common(object):
    
    _sec_keywords = [r'\A[\s]*[1-9]\d{3}\s*JP\n']
    _s_pattern = r'(?i)[\s]+([1-9]\d{3})[\s\.]+[a-zA-Z]{1,2}'
    _d_pattern = r'(?:\A|\n)[\s]*(20\d{2})[\s]*年[\s]*(\d{1,2})[\s]*月[\s]*(\d{1,2})[\s]*日[\s]*\n'
    
    def __init__(self, text):
        self._text = text

    def _g_filter(self, hits):
        g_filter = lambda x : x is not None
        return list(filter(g_filter, hits.groups()))
        
    def _recogn_sec(self):
        '''
        銘柄コード取得
        '''
        # 銘柄レポートかどうか判断する。
        for key in self._sec_keywords:
            #print('location:', 101)
            if re.search(key, self._text) is None:
                return ''
        for s_pattern in np.ravel([self._s_pattern]):
            hits = re.search(s_pattern, self._text)
            if hits is not None:
                #print('location:', 102)
                sec_code = self._g_filter(hits)
                #print('sec_code', sec_code)
                return sec_code[-1]
        else:
            #print('location:', 103)
            return ''
            
    _mapping_date = {
                        'JAN' : 1,
                        'FEB' : 2,
                        'MAR' : 3, 
                        'APR' : 4, 
                        'MAY' : 5, 
                        'JUN' : 6, 
                        'JUL' : 7, 
                        'AUG' : 8, 
                        'SEP' : 9, 
                        'OCT' : 10, 
                        'NOV' : 11, 
                        'DEC' : 12, 
                        'JANUARY' : 1, 
                        'FEBRUARY' : 2, 
                        'MARCH' : 3, 
                        'APRIL' : 4, 
                        'JUNE' : 6, 
                        'JULY' : 7, 
                        'AUGUST' : 8, 
                        'SEPTEMBER' : 9, 
                        'OCTOBER' : 10, 
                        'NOVEMBER' : 11, 
                        'DECEMBER' : 12,
                     }
                     
    def _recogn_rdate(self):
        #
        #レポート日付取得
        #
        def fmt_date(ymd):
            return '{0[0]}-{0[1]}-{0[2]}'.format(ymd)

        hits = re.search(self._d_pattern, self._text)
        # 銘柄コードが存在しない場合のレポート日付抽出
        if hits is not None:
            #print('location:', 1)
            return fmt_date(self._g_filter(hits))
        else:    
            #print('location:', 2)
            d_pattern = '(?i)(?:\A|\n|\s)+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|January|February|March|April|June|July|August|September|October|November|December)[\s]*[\-\/\:\.\,]*(\d{1,2})[\-\/\:\.\s\,]+(20\d{2})[\s]*\n'
            hits = re.search(d_pattern, self._text)
        if hits is not None:
            #print('location:', 3)
            m, d, y = self._g_filter(hits)
            return fmt_date([y, self._mapping_date[m.upper()], d])
        else:    
            #print('location:', 4)
            d_pattern = '(?i)(?:\A|\n|\s)+(\d{1,2})[\-\/\:\.\s\,]+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|January|February|March|April|June|July|August|September|October|November|December)[\s]+(20\d{2})[\s]*\n'
            hits = re.search(d_pattern, self._text)
        if hits is not None:
            #print('location:', 5)
            d, m, y = self._g_filter(hits)
            return fmt_date([y, self._mapping_date[m.upper()], d])
        else:
            #print('location:', 6)
            d_pattern = r'(20\d{2})[\s]*年[\s]*(\d{1,2})[\s]*月[\s]*(\d{1,2})[\s]*日[\s]*\n'
            hits = re.search(d_pattern, self._text)
        if hits is not None:
            #print('location:', 7)
            return fmt_date(self._g_filter(hits))
        else:
            #print('location:', 8)
            d_pattern = r'(?:\A|\n)[\s]*(20\d{2})[\s]*年[\s]*(\d{1,2})[\s]*月[\s]*(\d{1,2})[\s]*日'
            hits = re.search(d_pattern, self._text)
        if hits is not None:
            #print('location:', 9)
            return fmt_date(self._g_filter(hits))
        else:
            #print('location:', 10)
            d_pattern = r'(?:\A|\n)[\s]*(2[\s]*0[\s]*\d[\s]*\d[\s]*)[\s]*年[\s]*(\d[\s]*\d{0,1})[\s]*月[\s]*(\d[\s]*\d{0,1})[\s]*日'
            hits = re.search(d_pattern, self._text)
        if hits is not None:
            #print('location:', 11)
            rdate = [re.sub('\s', '', x) for x in self._g_filter(hits)]
            return fmt_date(rdate)
        #else:
            #print('location:', 12)
            #d_pattern = r'(?:\A|\n)[\s]*(20\d{2})[\s]*[一-龥ぁ-んァ-ン][\s]*(\d{1,2})[\s]*[一-龥ぁ-んァ-ン][\s]*(\d{1,2})[\s]*[一-龥ぁ-んァ-ン]'
            #hits = re.search(d_pattern, self._text)
        #if hits is not None:
            #print('location:', 13)
        #    return fmt_date(self._g_filter(hits))
        else:
            #print('location:', 14)
            return ''
            
    def items(self):
        sec_code = self._recogn_sec()
        report_date = self._recogn_rdate()
        return sec_code, report_date
        
class Item_GoldmanSachs(Item_common):
    '''
    ゴールドマン･サックス証券
    '''
    _sec_keywords = [r'(?:\A|\n)[\s]*20\d{2}[\s]*年[\s]*\d{1,2}[\s]*月[\s]*\d{1,2}[\s]*日[\s\S]{1,100}\([\s]*[1-9]\d{3}[\.\sa-zA-Z]+\)[\s]*\n']
    _s_pattern = r'(?:\A|\n)[\s]*20\d{2}[\s]*年[\s]*\d{1,2}[\s]*月[\s]*\d{1,2}[\s]*日[\s\S]{1,100}\(([1-9]\d{3})[\.\sa-zA-Z]+\)[\s]*\n'
    
class Item_Okasan(Item_common):
    '''
    岡三証券
    '''
    _sec_keywords = [r'(?:\A|\n)コード[\s]*[:：][\s]*[1-9]\d{3}\s*\n']
    _s_pattern = r'(?:\A|\n)コード[\s]*[:：][\s]*([1-9]\d{3})\s*\n'

class Item_Nomura(Item_common):
    '''
    野村證券
    '''
    _sec_keywords = ['レーティング[\s]*\n|\n決算コメント\n', '目標株価[\s]*\n|\n決算コメント\n']
    _s_pattern = [r'(?i)[\s]+([1-9]\d{3})[\s]+JP', r'[\(（][\s]*([1-9]\d{3})[\s]*[\)）]']
        
class Item_Daiwa(Item_common):
    '''
    大和証券グループ
    '''
    _sec_keywords = [r'(?:\A|\n).{1,20}\([\s]*[1-9]\d{3}[\s]*\)[\s\n]*20\d{2}[\s]*年[\s]*\d{1,2}[\s]*月[\s]*\d{1,2}[\s]*日[\s]*\n']
    _s_pattern = r'(?:\A|\n).{1,20}\([\s]*([1-9]\d{3})[\s]*\)[\s\n]*20\d{2}[\s]*年[\s]*\d{1,2}[\s]*月[\s]*\d{1,2}[\s]*日[\s]*\n'
    _d_pattern = r'(?:\A|\n).{1,20}\([\s]*\d{4}[\s]*\)[\s\n]*(20\d{2})[\s]*年[\s]*(\d{1,2})[\s]*月[\s]*(\d{1,2})[\s]*日[\s]*\n'

class Item_Mizuho(Item_common):
    '''
    みずほ証券
    '''
    _sec_keywords = ['(?:\A|\n)投資判断:']
    _s_pattern = r'[\s]*\(([1-9]\d{3})[\s\.\,a-zA-Z]*\)[\s]*\n'
        
class Item_Ichiyoshi(Item_common):
    '''
    いちよし経済研究所
    '''
    _sec_keywords = [r'20\d{2}[\s]*年[\s]*\d{1,2}[\s]*月[\s]*\d{1,2}[\s]*日[\s\S]{1,25}\([\s]*\d{4}.{0,10}\)']
    _s_pattern = r'20\d{2}[\s]*年[\s]*\d{1,2}[\s]*月[\s]*\d{1,2}[\s]*日[\s\S]{1,25}\([\s]*([1-9]\d{3}).{0,10}\)'
    _d_pattern = r'(?:\A|\n)\s*(20\d{2})[\s]*年[\s]*(\d{1,2})[\s]*月[\s]*(\d{1,2})[\s]*日[\n\s]+'
        
class Item_MUFJ_Morgan_Stanley(Item_common):
    '''
    三菱UFJモルガン・スタンレー証券
    '''
    _sec_keywords = ['(?:\A|\n)目標株価:[\d\s,]+円']
    _s_pattern = r'[\s]*\(([1-9]\d{3})[\s]*\)[\s]*\n'
        
class Item_Barclays(Item_common):
    '''
    バークレイズ証券
    '''
    _sec_keywords = [r'(?:\A|\n)\s*[1-9]\d{3}[\s\.a-zA-Z]{1,5}/\s*[1-9]\d{3}[\s\.a-zA-Z]{1,5}\n']
    _s_pattern = r'(?:\A|\n)\s*([1-9]\d{3})[\s\.a-zA-Z]{1,5}/\s*[1-9]\d{3}[\s\.a-zA-Z]{1,5}\n'
        
class Item_TokaiTokyo(Item_common):
    '''
    東海東京調査センター
    '''
    _sec_keywords = [r'(?:\A|\n)([\s]*20\d{2}[\s]*年[\s]*\d{1,2}[\s]*月[\s]*\d{1,2}[\s]*日[\s\S]{1,100}\([\s]*\d{4}[\s]*\)[\s]*\n|コード[\s]*[:：][\s]*\d{4}\s*\n)']
    _s_pattern = '(?:\A|\n)(?:[\s]*20\d{2}[\s]*年[\s]*\d{1,2}[\s]*月[\s]*\d{1,2}[\s]*日[\s\S]{1,100}\([\s]*(\d{4})[\s]*\)[\s\n]+|コード[\s]*[:：][\s]*(\d{4})\s*\n)'
    _d_pattern = '(?:\A|\n)(?:[\s]*(20\d{2})[\s]*年[\s]*(\d{1,2})[\s]*月[\s]*(\d{1,2})[\s]*日[\s]*\n|(?:作成日|発行日)[\s]*[:：][\s]*(\d{4})\s*[\./][\s]*(\d{1,2})[\s]*[\./][\s]*(\d{1,2})\s*\n)'

class Item_Iwaicosmo(Item_common):
    '''
    岩井コスモ証券
    '''
    _sec_keywords = [r'\([\s]*\d{4}.{0,25}\)[\s]*\n']
    _s_pattern = r'\([\s]*([1-9]\d{3}).{0,25}\)[\s]*\n'
        
class Item_SMBCNikko(Item_common):
    '''
    SMBC日興証券
    '''
    _s_pattern = r'\([\s]*([1-9]\d{3})[\s]*\)'
    _d_pattern = r'(?:\A|\n)[\s]*(20\d{2})[\s]*年[\s]*(\d{1,2})[\s]*月[\s]*(\d{1,2})[\s]*日'
    
    def _recogn_sec(self):
        '''
        銘柄コード取得
        '''
        if len(self._text) > 100:
            hits = re.search(self._s_pattern, self._text[0:100])
            if hits is not None:
                sec_code = self._g_filter(hits)
                #print('sec_code', sec_code)
                return sec_code[0]
        return ''

class Item_UBS(Item_common):
    '''
    UBS証券
    '''
    _sec_keywords = ['レーティング[\s]*\n', '目標株価[\s]*\n']
    _s_pattern = r'(?i)[\s]+([1-9]\d{3})[\s]+JP'

class Item_Morgan_Stanley_MUFG(Item_common):
    '''
    モルガン・スタンレーMUFG証券
    '''
    #_sec_keywords = [r'(?:\A|\n)[\s]*20\d{2}[\s]*年[\s]*\d{1,2}[\s]*月[\s]*\d{1,2}[\s]*日[\s\S]{1,100}\([1-9]\d{3}\)[\s]*\n']
    _sec_keywords = [r'(?i)[\s\(][1-9]\d{3}[\s]*JP[\s\)]*\n|\A[\s]*20\d{2}[\s]*年[\s]*\d{1,2}[\s]*月[\s]*\d{1,2}[\s]*日[\s\S]{1,100}\([1-9]\d{3}\)[\s]*\n']
    #_s_pattern = r'(?:\A|\n)[\s]*20\d{2}[\s]*年[\s]*\d{1,2}[\s]*月[\s]*\d{1,2}[\s]*日[\s\S]{1,100}\(([1-9]\d{3})\)[\s]*\n'
    _s_pattern = r'(?i)[\s\(]([1-9]\d{3})(?:JP|\s)*[\s\)]+\n'
    #_d_pattern = r'(?:\A|\n)(20\d{2})[\s\S]*年[\s\S]*(\d{1,2})[\s\S]*月[\s\S]*(\d{1,2})[\s\S]*日'
    #_d_pattern = r'(20\d{2})[\s\S]*年[[^\d]\n]*(\d{1,2})[[^\d]\n]*月[[^\d]\n]*(\d{1,2})[[^\d]\n]*日'
    _d_pattern = r'(20\d{2})[\s]*年[\s]*(\d{1,2})[\s]*月[\s]*(\d{1,2})[\s]*日'
    
class Item_Credit_Suisse(Item_common):
    '''
    クレディ・スイス証券
    '''
    _sec_keywords = [r'目標株価[\s]*\([\s]*円[\s]*\)']
    #_s_pattern = r'(?i)\([\s]*([1-9]\d{3})[\s]*(?:/[\s]*[1-9]\d{3})[\s\.a-zA-Z]+\)'
    _s_pattern = r'(?i)\([\s]*([1-9]\d{3})[\s]*(?:/[\s]*[1-9]\d{3}[\s\.a-zA-Z]+)*\)'

class Item_Merrill_Lynch(Item_common):
    '''
    メリルリンチ日本証券
    '''
    pass
        
class Item_JPMorgan(Item_common):
    '''
    JPモルガン証券
    '''
    _sec_keywords = [r'\([1-9]\d{3}[\sa-zA-Z]{0,5}\)\n', r'目標株価[\s]*[:：][\s\d,]*円[\s]*\n']
    _s_pattern = r'\(([1-9]\d{3})[\sa-zA-Z]{0,5}\)\n'
        
class Item_Deutsche(Item_common):
    '''
    ドイツ証券
    '''
    _sec_keywords = [r'(?i)(\A|\n)[\s]*Reuters[\s\n]+', r'[1-9]\d{3}[\s]*\.[\s]*[a-zA-Z]{1,5}[\s]*\n' ]
    _s_pattern = r'([1-9]\d{3})[\s]*\.[\s]*[a-zA-Z]{1,5}[\s]*\n'

class Item_TIW(Item_common):
    '''
    TIW
    '''
    _sec_keywords = [r'(?:\A|\n)[\s]*\d{4}[\s]*年[\s]*\d{1,2}[\s]*月[\s]*\d{1,2}[\s]*日[\s\S]{1,100}\(.{1,20}\-\d{4}[\s]*\)[\s]*\n']
    _s_pattern = r'(?:\A|\n)[\s]*20\d{2}[\s]*年[\s]*\d{1,2}[\s]*月[\s]*\d{1,2}[\s]*日[\s\S]{1,100}\(.{1,20}\-([1-9]\d{3})[\s]*\)[\s]*\n'
    _d_pattern = r'(?:\A|\n)(20\d{2})[\s]*年[\s]*(\d{1,2})[\s]*月[\s]*(\d{1,2})[\s]*日[\s]*\n'

class Item_Macquarie(Item_common):
    '''
    マッコーリーキャピタル証券
    '''
    pass

class Item_BNPparibas(Item_common):
    '''
    BNPパリバ証券
    '''
    pass

class Item_Citi(Item_common):
    '''
    シティグループ証券
    '''
    pass

class Item_Mizuho_Investors(Item_common):
    '''
    みずほインベスターズ証券（廃止）
    '''
    pass
        
class Item_Jeffreys(Item_common):
    '''
     ジェフリーズ証券
    '''
    pass
