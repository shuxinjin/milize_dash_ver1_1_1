# -*- coding: utf-8 -*-
'''
Name        : get_broker.py
Purpose     : テキストファイルから発行体判断
Created Date: 2018.08.08
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.08.08
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''
import sys
sys.path.append('../A50_Config')
sys.path.append('../A90_utils')

import numpy         as    np
import os
import pandas        as    pd
import re
import shutil
import traceback
import unicodedata

from   A50_Config.config_roll  import file_names
from   A90_utils.m_txtm_base   import m_txtm_base
from   A90_utils.localIO       import create_empty_file
from   A90_utils.localIO       import get_filelist
from   A90_utils.localIO       import get_fullpath_dirlist
from   A90_utils.localIO       import is_existing
from   .config_cln             import col_names
from   .config_cln             import brokers

class get_broker(m_txtm_base):

    _log_dir = '../../log/current_roll/cln'
    _log_prefix = 'r_broker_'
    _encoding = file_names.FILE_ENCODING
        
    _finished_files = set() # 重複防止

    def _read_file(self, in_file):
        '''
        1個のファイルから読み取り
        '''
        try:

            self._log('Read : {}'.format(in_file))
            isNotEmpty = lambda x : re.fullmatch('[\s　]*', x) is None

            with open(in_file, encoding='utf-8') as f:
                result_text = ''
                for line in f:
                    if isNotEmpty(line):
                        line = re.sub('[\r\n]+', '', line) # 改行削除
                        line = re.sub('[\s　]+', ' ', line) # 複数のスペースを一つにする
                        result_text += line
    
                broker_id = 999
                broker_name = 'その他'
    
                result_text = unicodedata.normalize('NFKC', result_text)
                #self._log(result_text)
                broker_found = False
                i_item = 2
                while not broker_found:
                    item_finished = True
                    for _, broker in sorted (brokers.brokers.items()):
                        if i_item < len(broker):
                            item_finished = False
                            if re.search(broker[i_item], result_text) is not None:
                                broker_id = broker[0]
                                broker_name = broker[1]
                                broker_found = True
                                #print(broker_id, broker_name)
                                break
                    if item_finished:
                        break
                    else:
                        i_item += 1
    
                record_id = re.sub('(?i)\.txt','', os.path.basename(in_file))
                self._finished_files.add(record_id)
                row = '{},{},{},{}'.format(record_id, in_file, broker_id, broker_name)
                return row

        except Exception  as e:
            info = ['error in {}:'.format(in_file)]
            info.append(str(e))
            info.extend(traceback.format_tb(e.__traceback__))
            self._log(info, file_info = self.__class__.__name__, error_flag = True)
            
            pass
            
    def _read_dir(self, in_dirs, in_ext):
        
        f_filter = lambda x : re.sub('\..*', '', x) not in self._finished_files

#        print('in_dirs =', in_dirs)
        for in_path in in_dirs:
            # read files
            files = filter(f_filter, get_filelist(in_path, in_ext))
            for file in files:
                in_file = os.path.join(in_path, file)
                yield self._read_file(in_file = in_file)
            sub_dirs = get_fullpath_dirlist(in_path)
            yield from self._read_dir(sub_dirs, in_ext)
    
    def main(self, text_dirs, out_file):
        
        if is_existing(out_file):
            # ファイル存在の場合、バックアップを取っておく
            out_file_bak = re.sub('.csv', '-bak.csv', out_file)
            shutil.copy2(out_file, out_file_bak)
            df = pd.read_csv(out_file, encoding = self._encoding, engine = 'python')
            self._finished_files = set(df[col_names.REPORT_ID].map(str))
            self._log('Reading existing file finished.')
        else:
            create_empty_file(out_file)
            with open(out_file, 'w', encoding = self._encoding) as f:
                row = '{},{},{},{}'.format(col_names.REPORT_ID, col_names.FULL_PATH, col_names.BROKER_ID, col_names.BROKER_NAME)
                print(row, file = f)
        
        in_ext = '.txt'
        in_dirs = np.ravel([text_dirs])
        with open(out_file, 'a', encoding = self._encoding) as f:
            for row in self._read_dir(in_dirs = in_dirs, in_ext = in_ext):
                print(row, file = f)
