# coding: utf-8
'''
Name        : NN_Mdl_XGBoost.py
Purpose     : NN Gradient Boost モデル
Created Date: 2018.03.20
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.03.20
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''

import sys
sys.path.append('./')

import traceback

from   xgboost       import XGBRegressor as regressor
from   .NN_Mdl_RF    import NN_Mdl_RF

class NN_Mdl_XGBoost(NN_Mdl_RF):
    
    _log_prefix = 'XGBoost_Model'
        
    # NN 作成
    def _buildModel(self, oldModel = None):

        # モデルの作成
        try:
            self._destroyModel(oldModel)
            
            params = {'n_estimators': 256, 'max_depth': 4, 'min_samples_split': 2, 'learning_rate': 0.005, 'loss': 'ls'}
#
            model = regressor(**params)
            
#            model = regressor()
            return model
            
        except Exception as e:
            info = ['モデル作成失敗']
            info.extend(e.args)
            info.extend(traceback.format_tb(e.__traceback__))
            self._log('\n'.join(info))
            
            self._destroyModel(model)
            
            return None

