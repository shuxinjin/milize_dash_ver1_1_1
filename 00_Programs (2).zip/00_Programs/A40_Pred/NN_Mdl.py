# coding: utf-8
'''
Name        : NN_Mdl.py
Purpose     : NN モデルの基底クラス
Created Date: 2018.10.10
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.10.10
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''

import sys
sys.path.append('../A90_utils')

import numpy                  as     np

from   sklearn.preprocessing  import StandardScaler, MinMaxScaler

from   A90_utils.m_txtm_base  import m_txtm_base
from   .NN_namedtuple         import Batch_Param
from   .NN_namedtuple         import NN_Param

class NN_Mdl(m_txtm_base):
    
    _log_prefix = 'NN_Model'
    
    _model = None
    _feature_importances = None
    '''
    分析のモデル
    '''
    def __init__(self, X = None, Y = None, neurons = None, nn_param : NN_Param = None, batch_param : Batch_Param = None, logger = None):
        
        self._neurons = neurons
        self._nn_param = nn_param
        self._batch_param = batch_param
        self._logger = logger
        self._look_back = 1
        
        if X is not None:
#            print('Original X:', X.shape, 'Original Y:', Y.shape)
#            print('====X====')
#            print(X.head())
#            print(X.tail())
#            print('====Y====')
#            print(Y.head())
#            print(Y.tail())
            # Scaling X and Y
#            if nn_param.x_norm == 'Standard':
#                scaler = StandardScaler()
#            else:
#                scaler = MinMaxScaler(feature_range=(0, 1))
#                
#            x_scaler = scaler.fit(X)
#            self._x_scaler = x_scaler
##            self._X = x_scaler.transform(X)
#            tmpX = x_scaler.transform(X)
#            self._X = self.recreate_DataX(tmpX, self._look_back)
#            
#            if nn_param.y_norm == 'Standard':
#                y_scaler = StandardScaler()
#            else:
#                y_scaler = MinMaxScaler(feature_range=(0, 1))
#            y_scaler = y_scaler.fit(Y)
#
#            self._y_scaler = y_scaler
#            self._Y = y_scaler.transform(Y)
            
#            print(self._X.max(), self._X.min())
#            print(self._Y.max(), self._Y.min())
        
            
#            print('Len X: ', len(self._X), 'Len Y:', len(self._Y))
#            act_len = min(len(self._X), len(self._Y))
            act_len = min(len(X), len(Y))
            
            self._X = self.recreate_DataX(X[-act_len:])
            
            self._Y = Y[-act_len:]

    def __exit__(self, type, value, traceback):
        super().__exit__(type, value, traceback)
        self.Destroy()
        
    def _splitTrainData(self):
        # Test Data
        trainRatio = self._batch_param.trainRatio
        
        testStart  = int(len(self._Y)*trainRatio)
        testEnd    = len(self._Y)

        f_train = lambda x : x < testStart or x >= testEnd
        trainIdx = list(filter(f_train, range(len(self._Y))))
        
        self._xTrain = self._X[trainIdx]
        self._xTest = self._X[testStart : testEnd]
        self._xPred = self._X[-1:]
        
        self._yTrain = self._Y[trainIdx]
        self._yTest = self._Y[testStart : testEnd]
        
    def Feature_Importances(self):
        return self._feature_importances
    
    def isEmpty(self):
        return self._model is None
    
    def Destroy(self):
        if self._model is not None:
            self._destroyModel(self._model)
