# coding: utf-8
'''
Name        : NN_Mdl_CNN.py
Purpose     : Convolutional (畳み込み) Neural Network モデル
Created Date: 2018.10.10
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.10.10
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''

import sys
sys.path.append('../A90_utils')

import traceback

from keras.models import Model
from keras.layers import Dense
from keras.layers import Dropout
from keras.layers import Activation
from keras.layers import Flatten
from keras.layers import Add
from keras.layers import Input
from keras.layers.advanced_activations import LeakyReLU
from keras.layers.convolutional import Conv2D, MaxPooling2D
from keras.layers.normalization import BatchNormalization
#from   sklearn.metrics        import mean_squared_error
#from   sklearn.metrics        import mean_absolute_error

from   .NN_Mdl_RF   import NN_Mdl_RF

class NN_Mdl_CNN(NN_Mdl_RF):
    
    _log_prefix = 'CNN_Model'
    
    _shape = (300, 1, 1) # 横の数、縦の数、RGB
    
    def recreate_DataX(self, X, look_back = 1):
        
        return X.reshape([-1] + list(self._shape))

    def _model_fit(self, model, X, Y):
#        print(Y.shape)
        model.fit(X, Y, batch_size = 20, epochs = 50, verbose = 0, shuffle = True)
        
    # NN 作成
    def _buildModel(self, oldModel = None):

        #resnet
        def resblock(x, filters, kernel_size):
            x_ = Conv2D(filters, kernel_size, padding='same')(x)
            x_ = BatchNormalization()(x_)
            x_ = Activation(LeakyReLU())(x_)
            x_ = Conv2D(filters, kernel_size, padding='same')(x_)
            x = Add()([x_, x])
            x = BatchNormalization()(x)
            x = Activation(LeakyReLU())(x)
            
            return x

        # モデルの作成
        try:
            self._destroyModel(oldModel)
            
            input_ = Input(shape = self._shape) # 横の数、縦の数、RGB
            
            c = Conv2D(32, (2, 1), padding='same')(input_)
            BatchNormalization()(c)
            c = Activation(LeakyReLU())(c)
            c = Dropout(0.25)(c)
            c = resblock(c, filters = 32, kernel_size=(2, 1))
            c = MaxPooling2D(pool_size=(2, 1))(c)
            
            c = Flatten()(c)
            c = Dense(30)(c)
            c = Activation(LeakyReLU())(c)
            c = Dropout(0.25)(c)
            c = Dense(1, activation='sigmoid')(c)
            
            model = Model(input_, c)
            
#            model.compile(loss='mae', optimizer='adam', metrics=['mae'])
            model.compile(loss='mae', optimizer='SGD', metrics=['mae'])
#            model.compile(loss='mae', optimizer='Nadam', metrics=['mae'])
            
            return model
            
        except Exception as e:
            info = ['モデル作成失敗']
            info.extend(e.args)
            info.extend(traceback.format_tb(e.__traceback__))
            self._log('\n'.join(info))
            
            self._destroyModel(model)
            
            return None

