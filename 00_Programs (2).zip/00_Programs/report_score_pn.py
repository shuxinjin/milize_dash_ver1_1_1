# -*- coding: utf-8 -*-
'''
Name        : report_score_pn.py
Purpose     : 極性値によるレポートのスコア算出
Created Date: 2018.9.3
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.9.3
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''
#import datetime

from   A04_Scoring.text_score_pn import text_score_pn
#from   A04_Scoring.search_func   import read_pn_value

if __name__ == '__main__':
    
#    dic = read_pn_value()
#    print(dic)
#    train_start = datetime.datetime.strptime('2015/08/01', '%Y/%m/%d')
#    train_end   = datetime.datetime.strptime('2018/07/31', '%Y/%m/%d')
#    pred_end    = train_end
#    with text_score_pn(train_start, train_end, pred_end) as t:
#        t.main(quarter_flg = True, create_flg = False)
#
    with text_score_pn() as t:
        t.main(quarter_flg = True, create_flg = False)
    
#    text = '''
#    【投資判断】マンションの契約は順調で、「Neutral」を継続
#    26 日に発表された 18 年 4∼6 月期の営業利益は、前年同期比 11％減の
#    146 億円で、通期の野村予想に対して 18％の進捗だったが、通期予想に対
#    して順調と考える。19.3 期通期は分譲マンション及び戸建で 6,000 戸の契
#    約、6,100 戸の売上計上を予想しているが、4∼6 月期の契約戸数は同 24％
#    増の 1,382 戸、6,100 戸に対する契約進捗率は 64％だったためである。4∼
#    6 月期は住宅の売上計上戸数が前年比 38％減で住宅事業は赤字だったが、
#    売上は 4Q 偏重と見て、業績予想は据え置き、「Neutral」を継続する。
#    
#    不動産運用事業のクローバル展開の第一歩として、3,000 億円の AUM を誇
#    る英国の不動産運用会社 Lothbury 社の 75％の株式を 18 年中にも取得す
#    る。不動産開発の機能も持つ会社で、欧米での不動産開発、運用のノウハウ
#    吸収に努める。当社は国内では上場 REIT や私募 REIT などで 1 兆 3,074
#    億円の預かり資産残高があり、投資資金を国内から英国へ、また英国から国
#    内へと向けるクロスボーダー取引を活発化させる可能性もある。
#    '''
#
#    with text_score_pn() as t:
#        t.pn(text, flag_cabocha = True, flag_val = True)
    

