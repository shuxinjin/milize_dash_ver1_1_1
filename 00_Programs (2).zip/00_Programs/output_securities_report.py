# coding: utf-8
'''
Name        : output_securities_report.py
Purpose     : 特定の銘柄を対象としたレポート出力
Created Date: 2018.9.3
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.9.3
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''
import sys
sys.path.append('./A50_Config')
sys.path.append('./A90_utils')

import os
import pandas as pd

from   A50_Config.config_roll import file_names
from   A90_utils.m_txtm_base  import m_txtm_base
from   A90_utils.localIO      import create_outdir

master_f = os.path.join(file_names.MASTER_DIR, 'out_master_securities.csv')
out_f    = os.path.join(file_names.HOME_DIR,   'report_securities_output.csv')

out_cols = [
        '構成銘柄', 
        'sec_code', 
        'report_id', 
        'report_date', 
        'broker_name', 
        'Summary',
        'Word Count',
        ]

class output_securities_report(m_txtm_base):

    _log_dir = '../log'
    _log_prefix = 'o_sec_report'

    def _search_text_dir(self, dirs):
        '''
        テキスト格納フォルダ確定
        '''
        o_files = []
        for d in dirs:
            for root, dirs, files in os.walk(d):
                for f in files:
                    if f == 'Summary.csv':
                        o_files.append(os.path.join(root, f))
        return o_files
    
    def main(self, dirs):
        
        out_df = pd.DataFrame()
        master_df = pd.read_csv(master_f, encoding = 'shift_jis', engine = 'python')
        files = self._search_text_dir(dirs)
        for f in files:
            df = pd.read_csv(f, encoding = 'shift_jis', engine = 'python', dtype = {'report_id':str})
            df = pd.merge(master_df, df, how = 'inner', left_on = ['4ケタコード'], right_on = ['sec_code'])
            out_df = pd.concat([out_df, df])
            
        out_df = out_df[out_cols]
        out_df['file_name'] = out_df['report_id'].map(lambda x : 'file://{}.pdf'.format(x))
        create_outdir(out_f)
        out_df.to_csv(out_f, encoding = 'shift_jis', index = False)
        
if __name__ == '__main__':
    
    dirs = ['../01_TextMining_Files/Nomura', '../01_TextMining_Files/SMBC', '../01_TextMining_Files/SMBC_Credit']

    with output_securities_report() as osr:
        osr.main(dirs)
