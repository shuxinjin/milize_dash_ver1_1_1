# coding: utf-8
'''
Name        : text_score_vector.py
Purpose     : アナリストレポートのセンチメントスコア算出(NRI論文⑥)
Created Date: 2018.8.8
Created by  : Wenfeng Huang (Milize Inc.)
Updated Date: 2018.8.8
Updated by  : Wenfeng Huang (Milze Inc.)
'''
import sys
sys.path.append('../A50_Config')
sys.path.append('../A90_utils')

import matplotlib.pyplot        as     plt
import numpy                    as     np
import operator                 as     op
import os
import pandas                   as     pd
from   sklearn                  import metrics
from   sklearn                  import preprocessing

from   A40_Pred.NN_namedtuple   import Batch_Param
from   A40_Pred.NN_namedtuple   import NN_Param
from   A40_Pred.NN_Config       import batch_param
from   A40_Pred.NN_Config       import nn_param
from   A40_Pred.NN_Config       import nn_model
from   A50_Config.config_roll   import file_names
from   A90_utils.localIO        import create_outdir
from   .config_scoring          import col_names
from   .text_roll_base          import text_roll_base

class text_score_vector(text_roll_base):

    _log_prefix = 'scor/scor'
    def _read_teacher(self, broker_name):
        teacher_f = os.path.join(file_names.MASTER_DIR, 'teacher_scores.csv')
        teacher_df = pd.read_csv(teacher_f, 
                                encoding = file_names.FILE_ENCODING, 
                                engine = 'python',
                                usecols = ['レポートID', '発行体名', 'センチメントスコア', 'レコメンドスコア']
                                )
        teacher_df = teacher_df[teacher_df['発行体名'] == broker_name]
        teacher_df = teacher_df[['レポートID', 'センチメントスコア', 'レコメンドスコア']]
        return teacher_df.rename(columns = {'レポートID' : col_names.REPORT_ID})
        
    def _read_vectors(self):
        vector_dir = os.path.dirname(os.path.dirname(self._file_names.TEXT_VECTOR_FILE))
        
        vector_df = pd.DataFrame()
        for root, dirs, files in os.walk(vector_dir):
            for f in files:
                if f.startswith('doc_vector') and f.endswith('.csv'):
                    full_f = os.path.join(root, f)
                    self._log(full_f)
                    tmp_v_df = pd.read_csv(full_f, 
                                            encoding = file_names.FILE_ENCODING, 
                                            engine = 'python',
                                            )
                    vector_df = vector_df.append(tmp_v_df)
        return vector_df.drop_duplicates(['report_id'])
        
    def _train(self, df_with_teacher, y_col):
        cols = [str(x) for x in range(300)]
        X = df_with_teacher[cols].values
        Y = df_with_teacher[y_col].values.reshape(-1, 1)/100
#        self._log(df_with_teacher)
#        self._log(y_col)
#        self._log(X)
#        self._log(Y)
        mdl = nn_model.model(X, Y, neurons = None, nn_param = nn_param, batch_param = batch_param, logger = self._logger)
        return mdl.Train()
    
    def main(self):
        
        brokers = ['野村證券', 'SMBC日興証券']
        b_y_col_thresholds = { '野村證券':     {'センチメントスコア' : 50, 'レコメンドスコア' : 75 },
                               'SMBC日興証券': {'センチメントスコア' : 50, 'レコメンドスコア' : 70 },
                            }
        
        scaler = preprocessing.MinMaxScaler(feature_range=(0, 1))
        for broker in brokers:
            y_col_thresholds = b_y_col_thresholds[broker]
            
            vector_teacher_f = os.path.join(file_names.HOME_DIR, 'scores', 'vector_teacher_scores_{}.csv'.format(broker))
            if os.path.exists(vector_teacher_f):
                self._log('Load existing files.')
                df_with_teacher = pd.read_csv(vector_teacher_f,
                                              encoding = file_names.FILE_ENCODING, 
                                              engine = 'python',
                                             )
                self._log('Loading finished.')
                                              
            else:
                self._log('Merge files....')
                teacher_df = self._read_teacher(broker_name = broker)
                vector_df = self._read_vectors()
                
                df_with_teacher = pd.merge(left = teacher_df, right = vector_df, how = 'inner', on = col_names.REPORT_ID)
                create_outdir(vector_teacher_f)
                df_with_teacher.to_csv(vector_teacher_f, encoding = file_names.FILE_ENCODING, index = False)
                self._log('Merging finished.')
            
    #        print(df_with_teacher.head())
            self._log(df_with_teacher.shape)
            
            out_cols = []
            
            # 精度などなどの出力用のDataframe
            df_acc = pd.DataFrame()
            
            for y_col in y_col_thresholds:
                
                yPred_train, yPred_test = self._train(df_with_teacher, y_col)
#                self._log(yPred_train)
#                self._log(yPred_test)
                
                len_test = len(yPred_test)
                predict_y = np.concatenate([yPred_train, yPred_test], axis = 0)
                out_col = y_col + '_Pred'
                df_with_teacher[out_col] = predict_y * 100
                test_y = (df_with_teacher[y_col].values[-len_test:] >= y_col_thresholds[y_col]).astype(int)
    #            print(predict_y.shape)
    #            print(test_y.shape)
                yPred_prob = scaler.fit(yPred_test.reshape(-1, 1)).transform(yPred_test.reshape(-1, 1))
                
#                self._log(yPred_test)
#                self._log(yPred_prob)
                fpr, tpr, thresholds = metrics.roc_curve(test_y, yPred_prob)
                auc = metrics.auc(fpr, tpr)
                plt.figure()
                plt.plot(fpr, tpr, label = 'ROC curve (AUC = {:.3}'.format(auc))
                plt.legend()
                plt.title('ROC curve for {}({})'.format(y_col, broker))
                plt.xlabel('False Positive Rate')
                plt.ylabel('True Positive Rate')
                plt.grid(True)
                
#                confmat = confusion_matrix(y_true = test_y, y_pred = (yPred_test > 0.5).astype(int))
                yPred_b = (yPred_test >= y_col_thresholds[y_col]/100).astype(int)
                
                acc_matrix = pd.DataFrame.from_dict(data = {
                        'accuracy' : metrics.accuracy_score(y_true = test_y, y_pred = yPred_b),
                        'precision' : metrics.precision_score(y_true = test_y, y_pred = yPred_b),
                        'recall' : metrics.recall_score(y_true = test_y, y_pred = yPred_b),
                        'f1_score' : metrics.f1_score(y_true = test_y, y_pred = yPred_b)},
                        orient = 'index',
                        columns = ['{}({})'.format(y_col, broker)]
                    )
                
                df_acc = pd.concat([df_acc, acc_matrix], axis = 1)
                
                confmat = metrics.confusion_matrix(y_true = test_y, y_pred = yPred_b)
                
                fig, ax = plt.subplots(figsize = (5, 5))
                ax.matshow(confmat, cmap = plt.cm.Blues, alpha = 0.3)
                for i in range(confmat.shape[0]):
                    for j in range(confmat.shape[1]):
                        ax.text(x = j, y = i, s = confmat[i, j], va = 'center', ha = 'center')
                plt.xlabel('予測値')
                plt.ylabel('教師データ')
                
    
                out_cols.extend([y_col, out_col])
                
#                return
                
            # 検証結果
            test_teacher_f = vector_teacher_f.replace('_{}.csv'.format(broker), '-test_{}.csv'.format(broker))
            out_cols = [col_names.REPORT_ID] + out_cols
            df_with_teacher[out_cols].to_csv(test_teacher_f, encoding = file_names.FILE_ENCODING, index = False)
            
            self._log(df_acc)
            test_acc_f = vector_teacher_f.replace('_{}.csv'.format(broker), '-acc_{}.csv'.format(broker))
            df_acc.to_csv(test_acc_f, encoding = file_names.FILE_ENCODING)
            
        
        self._log('Finished.')
