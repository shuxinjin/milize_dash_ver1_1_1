# -*- coding: utf-8 -*-
'''
Name        : sec_word_tree.py
Purpose     : 対象銘柄の用語関連図抽出
Created Date: 2018.10.26
Created by  : Wenfeng Huang (Milize Inc.)
Updated Date: 2018.10.26
Updated by  : Wenfeng Huang (Milze Inc.)
'''

import sys
sys.path.append('../A50_Config')
sys.path.append('../A60_gen_html')
sys.path.append('../A90_utils')

import numpy             as     np
import os
import pandas            as     pd

from   A50_Config.config_roll   import file_names
from   A50_Config.config_roll   import view_param
from   A90_utils.localIO        import create_outdir

from   .config_scoring          import col_names
from   .word_level_analyzer     import word_level_analyzer

class sec_word_tree(word_level_analyzer):
    
    def _create_html_data(self, sec, sec_name, common_words, vector_model, topn):
        # 言葉関連の確率
        if vector_model is None:
            self._log('No word for writing html: SEC_CODE = {} {}' .format(sec, sec_name))
            return None
        else:
            self._log('Writing html: SEC_CODE = {} {}' .format(sec, sec_name))
            relations_prob = {}
            max_refer_prob = 0.0
            min_refer_prob = 1.0
    
            for word in common_words:
                for target, prob in vector_model.most_similar(word, topn = topn):
                    relations_prob[(word, target)] = prob
                    max_refer_prob = np.fmax(max_refer_prob, prob)
                    min_refer_prob = np.fmin(min_refer_prob, prob)
                    
            create_outdir(file_names.WORD_NET_HTML)
            saved_dir = os.path.dirname(file_names.WORD_NET_HTML)
            
            threshold = view_param.threshold
            
            return (sec, 
                    sec_name, 
                    relations_prob, 
                    max_refer_prob, 
                    min_refer_prob, 
                    saved_dir, 
                    threshold)

    def _get_sec_count(self, quarter = None):
        
        sec_codes = sorted(set(self._matched_files[col_names.SEC_CODE]))

        vector_model_dic = {}
        for sec in sec_codes:
            self._log('SEC_CODE = {} {}' .format(sec, self._sec_names[sec]))
            _, vector_model = self._word_count(sec, quarter)
            vector_model_dic[sec] = vector_model
        
        return vector_model_dic
    
    def _out_sec_feature_words(self, sec, vector_model_dic, quarter = None):
        
        topn = view_param.topn
        
        sec_name = self._sec_names[sec]
        if quarter is None:
            in_count_f = file_names.WORD_COUNT.replace('.csv', '_{}.csv'.format(sec))
        else:
            in_count_f = file_names.WORD_COUNT.replace('.csv', '_{}_{}.csv'.format(sec, quarter[2]))
        
        self._log('SEC_CODE = {} {}' .format(sec, sec_name))
        vector_model = vector_model_dic[sec]
#            print(in_count_f)
        df = pd.read_csv(in_count_f, 
                         encoding = file_names.FILE_ENCODING, 
                         engine = 'python',
                         dtype = {col_names.SEC_CODE: str}
                         )
        
        top_words = df.iloc[:topn][col_names.DIC_WORD].values
        
        return self._create_html_data(
                         sec          = sec, 
                         sec_name     = sec_name, 
                         common_words = top_words, 
                         vector_model = vector_model, 
                         topn = topn)
    
        
    def main(self, sec_code, create_flg = False):
    
        # 対象レポート取得
        df = self._read_matched_files()
        self._matched_files = df[df[col_names.SEC_CODE] == sec_code] 
#        self._matched_files = self._read_matched_files()
        
        vector_model_dic = self._get_sec_count()
        
        return self._out_sec_feature_words(sec_code, vector_model_dic)
                
def search_word_tree(sec_code : str):
    with sec_word_tree() as swt:
        return swt.main(sec_code)