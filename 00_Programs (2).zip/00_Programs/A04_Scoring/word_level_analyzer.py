# -*- coding: utf-8 -*-
'''
Name        : word_level_analyezer.py
Purpose     : 対象ファイルから用語の頻度を抽出
Created Date: 2018.08.31
Created by  : Wenfeng Huang (Milize Inc.)
Updated Date: 2018.08.31
Updated by  : Wenfeng Huang (Milze Inc.)
'''

import warnings
warnings.filterwarnings(action = 'ignore', category = UserWarning, module = 'gensim')
import sys
sys.path.append('../A50_Config')
sys.path.append('../A60_gen_html')
sys.path.append('../A90_utils')

import codecs
from   collections              import Counter
from   datetime                 import datetime
from   dateutil.relativedelta   import relativedelta
from   gensim                   import models
import numpy             as     np
import operator          as     op
import os
import pandas            as     pd
import pickle
import re
from   sklearn.cluster   import KMeans

from   A50_Config.config_roll   import file_names
from   A50_Config.config_roll   import view_param
from   A50_Config.config_roll   import word_vectorizing
from   A60_html.generate_html   import generate_html_page
from   A90_utils.localIO        import create_outdir

from   .config_scoring          import col_names
from   .search_func             import read_uniq_mapping
from   .text_vector             import text_vector

class word_level_analyzer(text_vector):
    
    codecs.register_error('ignore', lambda e: ('', e.end))
    
    def __init__(self, logger = None):
        self._logger = logger
        self._uniq_mapping = read_uniq_mapping()

    def _search_token_dir(self, dirs):
        '''
        テキスト格納フォルダ確定
        '''
        o_dirs = []
        for d in dirs:
            for root, sub_dirs, _ in os.walk(d):
                for sd in sub_dirs:
                    if sd == 'text_token':
                        o_dirs.append(os.path.join(root, sd))
        return o_dirs
        
    def _search_item_files(self, dirs):
        '''
        テキスト格納フォルダ確定
        '''
        o_files = []
        for d in dirs:
            for root, _, files in os.walk(d):
                for f in files:
                    if len(f) > 11 and f[:-11] == 'record_items_':
                        full_f = os.path.join(root, f)
#                        self._log(full_f)
                        o_files.append(full_f)
        return o_files
    
    def _read_matched_files(self):
        master_f = file_names.SEC_MASTER_FILE
        master_df = pd.read_csv(master_f, 
                                encoding = file_names.FILE_ENCODING, 
                                engine = 'python',
                                dtype = {'4ケタコード': str}
                                )
        self._sec_names = {}
        
        for _, row in master_df.iterrows():
            self._sec_names[row['4ケタコード']] = row['構成銘柄']
        
#        for sec in self._sec_names:
#            self._log('{} {}'.format(sec, self._sec_names[sec]))
            
        d = file_names.HOME_DIR
        files = self._search_item_files([d])
        out_df = pd.DataFrame()
        for item_f in files:
            base_f = os.path.basename(item_f)
            dir_name = os.path.dirname(item_f)
            broker_f = os.path.join(dir_name, base_f.replace('record_items_', 'report_brokers_'))
            
            df = pd.read_csv(item_f, 
                             encoding = file_names.FILE_ENCODING, 
                             engine = 'python',
                             parse_dates = [col_names.REPORT_DATE],
                             dtype = {col_names.SEC_CODE: str}
                             )
            df = pd.merge(master_df, df, how = 'inner', left_on = ['4ケタコード'], right_on = [col_names.SEC_CODE])
            broker_df = pd.read_csv(broker_f, 
                             encoding = file_names.FILE_ENCODING, 
                             engine = 'python',
                             usecols = [col_names.REPORT_ID, col_names.FULL_PATH]
                             )
            df = pd.merge(df, broker_df, how = 'inner', left_on = [col_names.REPORT_ID], right_on = [col_names.REPORT_ID])
            out_df = pd.concat([out_df, df], sort = False)
        out_df = out_df[[col_names.REPORT_ID, col_names.SEC_CODE, col_names.REPORT_DATE, col_names.BROKER_ID, col_names.FULL_PATH]]
        out_df[col_names.FULL_PATH] = out_df[col_names.FULL_PATH].apply(lambda x : x.replace('02_Out_PDF_text', '03_Text_Cleansed'))
        out_f = file_names.WORD_COUNT_ITEM
        create_outdir(out_f)
        out_df.drop_duplicates().to_csv(out_f, encoding = file_names.FILE_ENCODING, index = False)
        return out_df
    
    def _load_sentences(self, path):
        with open(path, 'rb') as f:
            return pickle.load(f)
        
    def _save_sentences(self, sentences, path):
        create_outdir(path)
        with open(path, 'wb') as f:
            pickle.dump(sentences, f)

    def _read_document(self, path):
        with open(path, 'r', encoding = 'utf-8') as f:
            return f.read()
        
    def _get_sentences(self, quarter, sec_code, create_flg = False):
        
        if quarter is None:
            filtered_idx = op.eq(self._matched_files[col_names.SEC_CODE], sec_code)
        else:
            s_m, e_m, Q_name = quarter
            filtered_idx = op.and_(op.ge(self._matched_files[col_names.REPORT_DATE], s_m), \
                                   op.le(self._matched_files[col_names.REPORT_DATE], e_m),)
            filtered_idx = op.and_(filtered_idx, op.eq(self._matched_files[col_names.SEC_CODE], sec_code))
        
        corpus = self._matched_files.loc[filtered_idx, col_names.FULL_PATH].values
        broker_ids = self._matched_files.loc[filtered_idx, col_names.BROKER_ID].values
        sentences = self._corpus_to_sentences(corpus)
        self._logger.log('Loading sentence file finished.')
        
        return sentences, broker_ids
    
    def _word2vec(self, sentences):
        try:
            return models.Word2Vec(sentences,
                                   size      = word_vectorizing.vec_size,
                                   window    = word_vectorizing.vec_window,
                                   workers   = word_vectorizing.vec_workers,
                                   min_count = word_vectorizing.vec_min_count,
                                   iter      = word_vectorizing.vec_iter)
        except Exception  as e:
            self._log(e)
            return None

    def _clustering(self, word_vectors):
        km_mdl = KMeans(n_clusters   = word_vectorizing.word_cluster,
                        max_iter     = word_vectorizing.cluster_max_iter,
                        tol          = word_vectorizing.cluster_tol,
                        random_state = word_vectorizing.cluster_random_state)
        return km_mdl.fit_predict(word_vectors)
    
    def _check_filterring(self, word):
        pattern = word_vectorizing.noise_pattern
        return re.match(pattern, word) is None
    
    def _doc_word_table(self):
        '''
        文章と用語の関連テーブル
        '''
        self._log('Creating doc-word table...')
        self._log('Reading corpus files...')
        corpus = self._matched_files[col_names.FULL_PATH].values
        
        sentences = self._corpus_to_sentences(corpus)
        self._log('Corpus files finished.')
        
        finished_IDs =  set()
        
        out_f = file_names.DOC_WORD_FILE
        if os.path.exists(out_f):
            df = pd.read_csv(out_f, encoding = file_names.FILE_ENCODING, engine = 'python')
            finished_IDs = set(df[col_names.REPORT_ID])
        else:
            df = pd.DataFrame()
            
        for s in sentences:
            tag = s.tags[0]
            if tag not in finished_IDs:
                # 用語の出現頻度を降順表示
                df_words = sorted(Counter(s.words).items(), key = lambda x : -x[1])
                tmp_df = pd.DataFrame(data = df_words, columns = [col_names.DIC_WORD, col_names.WORD_FREQ])
                tmp_df[col_names.REPORT_ID] = str(tag)
                df = pd.concat([df, tmp_df], sort = False)
        out_cols = [col_names.REPORT_ID, col_names.DIC_WORD, col_names.WORD_FREQ]
        df[out_cols].drop_duplicates().to_csv(out_f, 
                      encoding = file_names.FILE_ENCODING, index = False)
        self._log('Doc-word table finished.')

    def _word_count(self, sec_code, quarter = None, create_flg = False):
        
#        uniq_dic = self._uniq_mapping
        filter_f = lambda x : len(x) > 1
#        self._logger.log('Word Counting started.')
        sentences, broker_ids = self._get_sentences(quarter, sec_code, create_flg)
        
        words = []
        mapped_sentences = []
        broker_common_words = {}
        for sentence, broker_id in zip(sentences, broker_ids):
            mapped_sentence = list(filter(filter_f, sentence.words))
#            mapped_sentence = list(map(lambda x : uniq_dic[x] if x in uniq_dic else '', mapped_sentence))
            mapped_sentence = list(filter(lambda x : x != '', mapped_sentence))
            mapped_sentences.append(mapped_sentence)
            words.extend(mapped_sentence)
            if broker_id not in broker_common_words:
                broker_common_words[broker_id] = set(mapped_sentence)
            else:
                broker_common_words[broker_id] |= set(mapped_sentence)
                
#        words = list(filter(lambda x : x != '', words))
        
#        self._logger.log('Word2Vec started.')
        vector_model = self._word2vec(mapped_sentences)
#        self._logger.log('Word2Vec finished.')
        
        self._domain_words = words
        counter = Counter(words)
        topn = word_vectorizing.word_topn
        common_words = counter.most_common(topn)
        
        if quarter is None:
            out_count_f = file_names.WORD_COUNT.replace('.csv', '_{}.csv'.format(sec_code))
        else:
            out_count_f = file_names.WORD_COUNT.replace('.csv', '_{}_{}.csv'.format(sec_code, quarter[2]))
        create_outdir(out_count_f)
        with open(out_count_f, 'w', encoding = file_names.FILE_ENCODING, errors = 'ignore') as o:
            
            o_devices = [o]
            for device in o_devices:
                print('order,word,count', file = device)
            for i, (word, count) in enumerate(common_words):
                for device in o_devices:
                    print('{},{},{}'.format(i + 1, word, count), file = device)
#        self._logger.log('Word Counting ended.')
        
        return broker_common_words, vector_model
    
    def _write_html(self, quarter, sec, sec_name, common_words, vector_model, topn):
        # 言葉関連の確率
        if vector_model is None:
            self._log('No word for writing html: SEC_CODE = {} {}' .format(sec, sec_name))
        else:
            self._log('Writing html: SEC_CODE = {} {}' .format(sec, sec_name))
            relations_prob = {}
            max_refer_prob = 0.0
            min_refer_prob = 1.0
    
            for word in common_words:
                for target, prob in vector_model.most_similar(word, topn = topn):
                    relations_prob[(word, target)] = prob
                    max_refer_prob = np.fmax(max_refer_prob, prob)
                    min_refer_prob = np.fmin(min_refer_prob, prob)
                    
            create_outdir(file_names.WORD_NET_HTML)
            saved_dir = os.path.dirname(file_names.WORD_NET_HTML)
            
            threshold = view_param.threshold
            
            generate_html_page(
                               quarter         = quarter,
                               sec_code        = sec,
                               sec_name        = sec_name, 
                               relations       = relations_prob, 
                               max_refer_prob  = max_refer_prob, 
                               min_refer_prob  = min_refer_prob, 
                               saved_dir       = saved_dir, 
                               prob_to_plot_threshold = threshold)
    
    def _get_sec_count(self, quarter = None):
        
        if quarter is None:
            sec_codes = sorted(set(self._matched_files[col_names.SEC_CODE]))
            out_common_f = file_names.WORD_COUNT.replace('.csv', '_common.csv')
        else:
            s_m, e_m, Q_name = quarter
            filtered_idx = op.and_(op.ge(self._matched_files[col_names.REPORT_DATE], s_m), \
                                   op.le(self._matched_files[col_names.REPORT_DATE], e_m),)
            sec_codes = sorted(set(self._matched_files.loc[filtered_idx, col_names.SEC_CODE]))
            out_common_f = file_names.WORD_COUNT.replace('.csv', '_common_{}.csv'.format(Q_name))

        vector_model_dic = {}
        broker_common_words = {}
        for sec in sec_codes:
            self._log('SEC_CODE = {} {}' .format(sec, self._sec_names[sec]))
            tmp_common_words, vector_model = self._word_count(sec, quarter)
            vector_model_dic[sec] = vector_model
            for broker_id in tmp_common_words:
                if broker_id not in broker_common_words:
                    broker_common_words[broker_id] = tmp_common_words[broker_id]
                else:
                    broker_common_words[broker_id] &= tmp_common_words[broker_id]
        
        all_common_words = set()
        for broker_id in broker_common_words:
            all_common_words |= broker_common_words[broker_id]
                    
        create_outdir(out_common_f)
        
        with open(out_common_f, 'w', encoding = file_names.FILE_ENCODING, errors = 'ignore') as o:
            o_devices = [o]
            for device in o_devices:
                print('{},{}'.format(col_names.DIC_KEY, col_names.DIC_WORD), file = device)
            for i, word in enumerate(sorted(all_common_words)):
                for device in o_devices:
                    print('{},{}'.format(i + 1, word), file = device)
                    
        return vector_model_dic, all_common_words
    
    def _out_sec_feature_words(self, vector_model_dic, all_common_words, quarter = None):
        
        topn = view_param.topn
        
        for sec in sorted(vector_model_dic.keys()):
            sec_name = self._sec_names[sec]
            if quarter is None:
                in_count_f = file_names.WORD_COUNT.replace('.csv', '_{}.csv'.format(sec))
                out_count_f = file_names.WORD_COUNT.replace('.csv', '_{}_feature.csv'.format(sec))
            else:
                in_count_f = file_names.WORD_COUNT.replace('.csv', '_{}_{}.csv'.format(sec, quarter[2]))
                out_count_f = file_names.WORD_COUNT.replace('.csv', '_{}_feature_{}.csv'.format(sec, quarter[2]))
            
            self._log('SEC_CODE = {} {}' .format(sec, sec_name))
            vector_model = vector_model_dic[sec]
#            print(in_count_f)
            df = pd.read_csv(in_count_f, 
                             encoding = file_names.FILE_ENCODING, 
                             engine = 'python',
                             dtype = {col_names.SEC_CODE: str}
                             )
            df = df[~df[col_names.DIC_WORD].isin(all_common_words)]
            df.to_csv(out_count_f, encoding = file_names.FILE_ENCODING, index = False)
            top_words = df.iloc[:topn][col_names.DIC_WORD].values
            self._write_html(
                             quarter      = quarter,
                             sec          = sec, 
                             sec_name     = sec_name, 
                             common_words = top_words, 
                             vector_model = vector_model, 
                             topn = topn)
        self._logger.log('Writing HTML file finished.')
    
    def _get_quarter_name(self, d):
        y = d.year
        q = int((d.month - 1)/3)
        if q == 0:
            q = 4
            y -= 1
        return '{}_Q{}'.format(y, q)
    
    def _get_quarter_month(self, d):
        q = int((d.month - 1) / 3)
        s_m = datetime(d.year, q*3 + 1, 1)
        e_m = s_m + relativedelta(months = 3) - relativedelta(days = 1)
        
        return s_m, e_m, self._get_quarter_name(s_m)
    
    def _get_quarters(self, min_date, max_date):
        quarters = []
        s_m = min_date
        s_m, e_m, Q_name = self._get_quarter_month(s_m)
        
        while s_m <= max_date:
            quarters.append((s_m, e_m, Q_name))
            s_m += relativedelta(months = 3)
            s_m, e_m, Q_name = self._get_quarter_month(s_m)
        
        return quarters
        
    def main(self, quarter_flg = False, create_flg = False):
    
        # 対象レポート取得
        self._matched_files = self._read_matched_files()
        
        # create doc_word table
        self._doc_word_table()
        
        if quarter_flg:
            min_date = self._matched_files[col_names.REPORT_DATE].min()
            max_date = self._matched_files[col_names.REPORT_DATE].max()
            quarters = self._get_quarters(min_date, max_date)
            
            for quarter in quarters:
                self._log('{} {} {}'.format(quarter[0].strftime('%Y-%m-%d'), quarter[1].strftime('%Y-%m-%d'), quarter[2]))
                vector_model_dic, all_common_words = self._get_sec_count(quarter)
                self._out_sec_feature_words(vector_model_dic, all_common_words, quarter)
        else:
            vector_model_dic, all_common_words = self._get_sec_count()
            self._out_sec_feature_words(vector_model_dic, all_common_words)
                
#        
            
