# -*- coding: utf-8 -*-
'''
Name        : config_scoring.py
Version     : 2.0
Purpose     : スコア化で使われる定数、共通メソッドのまとめ
Created Date: 2018.08.08
Created by  : Wenfeng Huang (Milize Inc.)
Updated Date: 2018.08.08
Updated by  : Wenfeng Huang (Milze Inc.)
'''
import sys
sys.path.append('../A50_Config')

from   datetime               import date, datetime
from   dateutil.relativedelta import relativedelta
import numpy                  as     np
import operator               as     op
import os
import pandas                 as     pd

from   A50_Config.config_roll import common_file_names
from   A50_Config.config_roll import doc_clustering
from   A50_Config.config_roll import roll

class col_names:
    
    SEC_CODE         = 'sec_code'
    SEC_NAME         = 'sec_name'
    SECTOR_CODE      = 'sector_code' #業種コード
    REPORT_ID        = 'report_id'
    REPORT_DATE      = 'report_date'
    BROKER_ID        = 'broker_id'
    BROKER_NAME      = 'broker_name'
    FULL_PATH        = 'full_path'
    PDF_PATH         = 'pdf_path'
    SETTLEMENT_TERM  = 'settlement_term'
    REPORT_VAL       = 'report_prof_dif1'
    DOC_CLUSTER      = 'cluster' #文章の分類番号
    VEC_NAME         = 'vec_name' # 標準ベクトル出力用ベクトル名
    SENTI_SCORE      = 'senti_score' # センチメントスコア
    REV_FLG          = 'revision_flag' # 業績修正フラグ -1, 0, 1
    REV_VAL          = 'revision_val' # 業績修正値（相対）
    SENTI_SCORE_DATE = 'score_date' # センチメントスコアの基準日付
    SENTI_SCORE_MAX  = 'score_max' # センチメントスコア最大値
    SENTI_SCORE_MIN  = 'score_min' # センチメントスコア最小値
    SENTI_SCORE_MED  = 'score_median' # センチメントスコア中央値
    SENTI_SCORE_AVG  = 'score_average' # センチメントスコア単純平均値
    SENTI_SCORE_COMP = 'score_composite' # 集計済みセンチメントスコア（単純平均値）
    
    REPORT_COUNT     = 'report_count' # 有効レポート数
    VALUATE_DATE     = 'valuate_date' # 評価日
    CALC_DATE        = 'calc_date' # 計算実施日
    
    SUMMARY          = 'summary'
    WORD_COUNT       = 'word_count'

    DIC_WORD         = 'word'
    DIC_KEY          = 'no'
    DIC_PNVALUE      = 'pn'
    WORD_CLUSTER     = 'cluster'
    # 出現頻度
    WORD_FREQ        = 'freq'
    
    SCORE_SENTI      = 'センチメントスコア'
    SCORE_SENTI_V    = 'センチメントスコア（ベクトルベース）'
    SCORE_SENTI_PN   = 'センチメントスコア（極性値ベース）'
    SCORE_SENTI_REF  = 'センチメントスコア（参考値）'
    SCORE_RECOMM     = 'レコメンデーションスコア'
    SCORE_RECOMM_REF = 'レコメンデーションスコア（参考値）'
    
class data_format:
    OFFSET = 3
    OFFSET_COL = [ \
        col_names.REPORT_ID, \
        col_names.REPORT_DATE, \
        col_names.SETTLEMENT_TERM, \
        ]
    LABEL_CLASS = 2 # プラスとマイナス
    

class file_names:
    
    '''
    ファイルのエンコーディング
    '''
    FILE_ENCODING = 'shift_jis'
    
    _date_fmt = '%Y_%m_%d'
    _pred_end = None
    def __init__(self, train_start, train_end, pred_end):
        '''
        train_start: Training start date
        train_end  : Training end date
        pred_end   : Prediction end date
        
        '''
        self._train_start = None if train_start is None else train_start.strftime(self._date_fmt)
        self._train_end = None if train_end is None else train_end.strftime(self._date_fmt)
        self._pred_end = None if pred_end is None else pred_end.strftime(self._date_fmt)

        mm = datetime.now() if self._pred_end is None else datetime.strptime(self._pred_end, self._date_fmt)
        self._score_file_name = 'A{}_y{}c{}'.format(mm.strftime('%Y%m'), int(roll.ROLL_WINDOW/12), doc_clustering.doc_cluster)
        
    '''
    ホームディレクトリ
    '''
    HOME_DIR = os.path.join(common_file_names.HOME_DIR, 'current_rolling')
    
    HOME_DIR_SUB = '{}/NRI_{}M_{}M'.format(HOME_DIR, roll.ROLL_WINDOW, roll.ROLL_STEP_LEN)
    
    cleansed_folders = ['']
    '''
    クレンジング済みファイルを格納するフォルダ
    '''
    CLNS_DIR = []
    for folder in cleansed_folders:
        CLNS_DIR.append(os.path.join(common_file_names.CLNS_DIR, folder))

    '''
    該当レポート一覧ファイル
    '''
    REVISION_FILES = []
    REV_DIR = '{}/revision'.format(HOME_DIR)
    filter_f = lambda x : x.endswith('.csv')
    for root, _, files in os.walk(REV_DIR):
        for file in list(filter(filter_f, files)):
            REVISION_FILES.append(os.path.join(root, file))

    '''
    Text token
    '''
    TEXT_TOKEN = '{}/text_token'.format(HOME_DIR)
#    TEXT_TOKEN_OUT = '{}/text_token/{}'.format(HOME_DIR, 'rolling')
#    token_folders = ['2007-2017', 'rolling']
#    TEXT_TOKEN = []
#    for folder in token_folders:
#        TEXT_TOKEN.append('{}/text_token/{}'.format(HOME_DIR, folder))
    '''
    Text summary
    '''
    TEXT_SUMMARY = '{}/text_summary'.format(HOME_DIR)

    '''
    Text Vector
    '''
    @property
    def TEXT_DOC2VEC_MODEL(self):
        return '{0}/text_vector/{1}/ana_doc2vec{1}.model'.format(self.HOME_DIR_SUB, self._train_end)
    @property
    def TEXT_VECTOR_FILE(self): # 学習用
        return '{0}/text_vector/{1}/doc_vector{1}.csv'.format(self.HOME_DIR_SUB, self._train_end)
    '''
    Text Clustering
    '''
    @property
    def TEXT_CLUSTER_TRAIN_FILE(self):
        return '{0}/text_cluster/train/{1}/ana_doc_cluster{1}_{2}.csv'.format(self.HOME_DIR_SUB, \
                                      self._train_end, doc_clustering.doc_cluster)
    @property
    def TEXT_CLUSTER_PRED_FILE(self):
        return '{0}/text_cluster/pred/{1}/ana_doc_cluster{1}_{2}.csv'.format(self.HOME_DIR_SUB, \
                                      self._pred_end, doc_clustering.doc_cluster)
    '''
    銘柄ごとのクラスタ分布
    '''
    @property
    def TEXT_SEC_CLUSTER_TRAIN_FILE(self):
        return '{0}/text_cluster/train/{1}/dist_sec_cluster{1}_{2}.csv'.format(self.HOME_DIR_SUB, \
                                      self._train_end, doc_clustering.doc_cluster)
    @property
    def TEXT_SEC_CLUSTER_PRED_FILE(self):
        return '{0}/text_cluster/pred/{1}/dist_sec_cluster{1}_{2}.csv'.format(self.HOME_DIR_SUB, \
                                      self._pred_end, doc_clustering.doc_cluster)
    '''
    Standard positive/negative document vectors
    '''
    @property
    def TEXT_STD_VECTOR_FILE(self):
        return '{0}/text_standard/{1}/ana_doc_std_vec{1}_{2}.csv'.format(self.HOME_DIR_SUB, \
                                      self._pred_end, doc_clustering.doc_cluster)
    '''
    Sentiment score
    '''
#    @property
#    def TEXT_SENT_FILE(self):
#        return '{0}/text_senti_score/{1}/text_senti_score{1}_{2}.csv'.format(self.HOME_DIR, \
#                                      self._pred_end, data_constant.doc_cluster)

    def text_sent_file(self, end_date):
        return '{0}/text_senti_score/{1}/text_senti_score{1}_{2}.csv'.format(self.HOME_DIR_SUB, \
                                      end_date.strftime(self._date_fmt), doc_clustering.doc_cluster)
    
#    TEXT_SENT_DAILY_FILE = '{0}/text_senti_score/roll_monthly/daily/text_senti_score_daily_{1}.csv'.format(HOME_DIR_SUB, \
#                                      data_constant.doc_cluster)
#    TEXT_SENT_MONTHLY_FILE = '{0}/text_senti_score/roll_monthly/monthly/text_senti_score_monthly_{1}.csv'.format(HOME_DIR_SUB, \
#                                      data_constant.doc_cluster)
    #score_file_name = 'ANR_y{}c{}'.format(int(data_constant.ROLL_WINDOW/12), data_constant.doc_cluster)
#    mm = datetime.now() if _pred_end is None else datetime.strptime(_pred_end, _date_fmt)
#    score_file_name = 'A{}_y{}c{}'.format(mm.strftime('%Y%m'), int(data_constant.ROLL_WINDOW/12), data_constant.doc_cluster)
#    
#    TEXT_SENT_DAILY_FILE = '{0}/text_senti_score/roll_monthly/daily/{1}_d.csv'.format(HOME_DIR_SUB, \
#                                      score_file_name)
#    TEXT_SENT_MONTHLY_FILE = '{0}/text_senti_score/roll_monthly/monthly/{1}.csv'.format(HOME_DIR_SUB, \
#                                      score_file_name)

    @property
    def TEXT_SENT_DAILY_FILE(self):
        return  '{0}/text_senti_score/roll_monthly/daily/{1}_d.csv'.format(self.HOME_DIR_SUB, self._score_file_name)
        
    @property
    def TEXT_SENT_MONTHLY_FILE(self):
        return  '{0}/text_senti_score/roll_monthly/monthly/{1}.csv'.format(self.HOME_DIR_SUB, self._score_file_name)
    
class brokers(object):
    '''
    発行体
    '''
    brokers = { \
                    1 : "ゴールドマン・サックス証券", \
                    4 : "モルガン・スタンレーMUFG証券", \
                    6 : "マッコーリーキャピタル証券", \
                    7 : "メリルリンチ日本証券", \
                    10: "UBS証券", \
                    15: "JPモルガン証券", \
                    18: "岡三証券", \
                    21: "ドイツ証券", \
                    22: "野村證券", \
                    23: "大和証券グループ", \
                    24: "BNPパリバ証券", \
                    26: "シティグループ証券", \
                    28: "みずほ証券", \
                    29: "クレディ・スイス証券", \
                    30: "いちよし経済研究所", \
                    34: "三菱UFJモルガン・スペンサー証券", \
                    46: "バークレイズ証券", \
                    56: "TIW", \
                    60: "東海東京調査センター", \
                    61: "岩井コスモ証券", \
                    90: "ジェフリーズ証券", \
                    97: "SMBC日興証券", \
                }

def convert_to_date(d):
    t = type(d)
    if t is datetime or t is pd.Timestamp:
        return d.date()
    else:
        return d

def read_matching_records(start_date, end_date):
    '''
    メモリ節約するため、必要分のデータのみ抽出する
    start_date: 開始日付
    end_date  : 終了日付
    '''
    s_date = convert_to_date(start_date)
    e_date = convert_to_date(end_date)
        
    fileList = np.ravel([file_names.REVISION_FILES])
    df = pd.read_csv(fileList[0], encoding = file_names.FILE_ENCODING, parse_dates = [col_names.REPORT_DATE], engine = 'python')
    df[col_names.REPORT_DATE] = df[col_names.REPORT_DATE].map(convert_to_date)
    idx = op.and_(op.ge(df[col_names.REPORT_DATE], s_date), \
                  op.le(df[col_names.REPORT_DATE], e_date))
    df = df[idx]
    for file in fileList[1:]:
        df1 = pd.read_csv(file, encoding = file_names.FILE_ENCODING, parse_dates = [col_names.REPORT_DATE], engine = 'python')
        df1[col_names.REPORT_DATE] = df1[col_names.REPORT_DATE].map(convert_to_date)
        idx = op.and_(op.ge(df1[col_names.REPORT_DATE], s_date), \
                      op.le(df1[col_names.REPORT_DATE], e_date))
        df = pd.concat([df, df1[idx]])
        
    df.sort_values([col_names.REPORT_DATE, col_names.REPORT_ID], inplace = True)
    df.drop_duplicates([col_names.REPORT_ID], keep = 'last', inplace = True)
    
    df.reset_index(drop=True, inplace = True)
    return df

def get_month_end(d : date):
    next_month = d + relativedelta(months = 1)
    return next_month.replace(day = 1) - relativedelta(days = 1)
    
def get_lower_month_date(d, month_n):
    #三か月前
    month = d.month - month_n
    year = d.year
    while month <= 0:
        month += 12
        year -= 1
    while month > 12:
        month -= 12
        year += 1
    return date(year, month, 1)

if __name__ == '__main__':
    
    print(roll.ROLL_WINDOW)    
