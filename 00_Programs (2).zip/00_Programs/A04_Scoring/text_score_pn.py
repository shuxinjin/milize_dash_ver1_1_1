# -*- coding: utf-8 -*-
'''
Name        : text_score_pn.py
Purpose     : 極性値によるスコア算出
Created Date: 2018.10.23
Created by  : Wenfeng Huang (Milize Inc.)
Updated Date: 2018.10.23
Updated by  : Wenfeng Huang (Milze Inc.)
'''

import CaboCha
import MeCab
import nltk
import numpy    as np
import operator as op
import os
import pandas   as pd
import re

from   A50_Config.config_roll   import file_names
from   A90_utils.localIO        import create_outdir

from   .config_scoring          import col_names
from   .search_func             import read_pn_value
#from   .text_score_vector       import text_score_vector
from   .word_level_analyzer     import word_level_analyzer

            
#class text_score_pn(text_score_vector):
class text_score_pn(word_level_analyzer):
    
    _out_score_cols = [col_names.REPORT_ID, 
                       col_names.SEC_CODE, 
                       col_names.BROKER_ID, 
                       col_names.SENTI_SCORE]
    
#    def __init__(self, train_start, train_end, pred_end, logger = None):
#        super().__init__(train_start, train_end, pred_end, logger)
    
    def __init__(self, logger = None):
        super().__init__(logger)
        
        self.jp_sent_tokenizer = nltk.RegexpTokenizer(u'[^　！!？?。]*[！!？?。\n]')
        self.mecab = MeCab.Tagger()
        self.cabocha = CaboCha.Parser('-f1')
        self.pndic = read_pn_value()
        
    def chunk_by(self, func, col):
        '''
        `func`の要素が正のアイテムで区切る
        '''
        result = []
        for item in col:
            if func(item):
                result.append([])
            else:
                result[len(result) - 1].append(item)
        return result
    
    def has_chunk(self, token):
        #'''
        #チャンクがあるかどうか
        #チャンクがある場合、その単語が先頭になる
        #'''
        return token.chunk is not None
    
    def to_tokens(self, tree):
        '''
        #解析済みの木からトークンを取得する
        '''
        return [tree.token(i) for i in range(0, tree.size())]
    
    def concat_tokens(self, i, tokens, lasts):
        '''
        単語を意味のある単位にまとめる
        '''
        if i == -1:
            return None
        word = tokens[i].surface
        last_words = map(lambda x: x.surface, lasts[i])
        return word + ''.join(last_words)
                
    def mecab_list(self, s):
        '''return list of mecab analysis'''
        s = self.mecab.parse(s)
        #print(s)
        return [word.split(',') for word in s.replace('\t', ',').split('\n')[:-2]]
    
    def pn_sub(self, s):
        '''return average positive vs negative points of text'''
        #points_of_s = {'名詞':0,'助動詞':0,'動詞':0,'形容詞':0,'副詞':0,'助詞':0}
        
        ana_res = self.mecab_list(s)
        #print(ana_res)
        rev_count  = 0  # 反転回数
        points_of_s = 0
        for line in ana_res:
            #print(line)
            try:
                # ことば
                word = line[7]
                #word = line[0]
                # 品詞
                word_part = line[1]
#                # カタカナ
#                word_yomi = line[8]
                #print(word, word_part, word_yomi)
            except IndexError as e:
                #skip symbols like (, ), $, %, 
                continue
            if word in self._uniq_mapping:
                uniq_word = self._uniq_mapping[word]
                if uniq_word in self.pndic:
                    points_of_s += self.pndic[uniq_word]
            elif (word_part == '助動詞' and word == 'ない')  or (word_part == '助詞' and word == 'か') or (word_part == '記号' and word == '？') or word == '?':
                #print(word, word_part, -1)
                rev_count += 1
            else:
                continue
        rev_count = (rev_count % 2)
        return points_of_s, rev_count
    
    def pn_sentence(self, s, flag_cabocha = True, flag_val = True):
        '''
        discription  : 文章
        flag_cabocha : Cabocha使用フラグ
        flag_val     : 評価フラグ
        '''

        if flag_cabocha:
            tree = self.cabocha.parse(s)
            tokens = self.to_tokens(tree)
            
            head_tokens = list(filter(self.has_chunk, tokens))
            
            lasts = self.chunk_by(self.has_chunk, tokens)
            
            links = map(lambda x: x.chunk.link, head_tokens)
            link_words = map(lambda x: self.concat_tokens(x, head_tokens, lasts), links)
            
            last_end = None
            result_pt = {}
            result_rev = {}
            orig_rev = {}
            rev_cnt = 0
            for (i, to_word) in enumerate(link_words):
                from_word = self.concat_tokens(i, head_tokens, lasts)
#                print("{0}: {1} => {2}".format(i, from_word, to_word))
                if flag_val:
                    if from_word != last_end and from_word not in result_pt.keys():
                        result_pt[from_word], result_rev[from_word] = self.pn_sub(from_word)
                        orig_rev[from_word] = 1 if result_rev[from_word] == 0 else -1
                    if to_word != None and to_word not in result_pt.keys():
                        result_pt[to_word], result_rev[to_word] = self.pn_sub(to_word)
                        orig_rev[to_word] = 1 if result_rev[to_word] == 0 else -1
                    if to_word != None:
                        result_rev[to_word] += result_rev[from_word]
                        # 反転語を次の言葉に伝える
                        rev_cnt = result_rev[to_word]
#                    if to_word is None:
#                        print("{0}: {1} => {2} [{3} => *]".format(i, from_word, to_word, result_pt[from_word]*orig_rev[from_word]))
#                    else:
#                        print("{0}: {1} => {2} [{3} => {4}]".format(i, from_word, to_word, result_pt[from_word]*orig_rev[from_word], result_pt[to_word]*orig_rev[to_word]))
                else:
#                    print("{0}: {1} => {2}".format(i, from_word, to_word))
                    continue
                last_end = to_word
                
            total_pt = 0.0
            for v in result_pt.values():
                total_pt += float(v)
            if rev_cnt % 2 == 1:
                total_pt *= -1
                
            return max(min(total_pt, 10), -10)

        else:
            print(s, self.pn_sub(s))
            return None

    def pn(self, discription, flag_cabocha = True, flag_val = True):
        '''
        discription  : 文章
        flag_cabocha : Cabocha使用フラグ
        flag_val     : 評価フラグ
        '''

        if discription is not None:
            if flag_val:
                result_pt = []
                for (i, s) in enumerate(self.jp_sent_tokenizer.tokenize(discription)):
                    if s != '' and s != '\n':
                        self._log('[{}]:\n {}\n'.format(i, s))
                        pt = self.pn_sentence(s, flag_cabocha, flag_val)
                        self._log('Point = {}\n'.format(pt))
                        result_pt.append(pt)
                    
                result_pt = np.array(result_pt)
                self._log('Final = {}'.format(result_pt.mean()))
                return result_pt
            else:
                self.pn_sentence(discription, flag_cabocha, flag_val)

    def _corpus_to_sentences(self, corpus):
        docs = [(re.sub(r'\.txt$', '', os.path.basename(x)), self._read_document(x)) for x in corpus]
        return docs

    def _get_sec_score(self, sec_code, quarter = None):
        
        sentences, brokers = self._get_sentences(quarter = quarter, sec_code = sec_code)
        self._log('Scoring finished.')
        
        df_data = []
        for (report_id, doc), broker_id in zip(sentences, brokers):
            score = self.pn_sentence(doc)
            df_data.append([report_id, sec_code, broker_id, int(score)])
            
        return pd.DataFrame(data = df_data, columns = self._out_score_cols)

    def _get_all_score(self, quarter = None):
        
        if quarter is None:
            sec_codes = sorted(set(self._matched_files[col_names.SEC_CODE]))
        else:
            s_m, e_m, Q_name = quarter
            filtered_idx = op.and_(op.ge(self._matched_files[col_names.REPORT_DATE], s_m), \
                                   op.le(self._matched_files[col_names.REPORT_DATE], e_m),)
            sec_codes = sorted(set(self._matched_files.loc[filtered_idx, col_names.SEC_CODE]))
        
        df = pd.DataFrame(columns = self._out_score_cols)
        for sec in sec_codes:
            self._log('SEC_CODE = {} {}' .format(sec, self._sec_names[sec]))
            sec_df = self._get_sec_score(sec, quarter)
            df = df.append(sec_df)

        return df.drop_duplicates()

    def _out_sec_score(self, df):
        
        df.drop_duplicates(inplace = True)
        # [-10, 10] --> [0, 100]
        df[col_names.SENTI_SCORE] = df[col_names.SENTI_SCORE].apply(lambda x : int((x + 10) * 5))
        pn_score_f = os.path.join(file_names.HOME_DIR, 'scores', 'pn_scores.csv')
        create_outdir(pn_score_f)
        df.to_csv(pn_score_f, encoding = file_names.FILE_ENCODING, index = False)
    
    def main(self, quarter_flg = False, create_flg = False):
    
        # 対象レポート取得
        self._matched_files = self._read_matched_files()
        
        if quarter_flg:
            min_date = self._matched_files[col_names.REPORT_DATE].min()
            max_date = self._matched_files[col_names.REPORT_DATE].max()
            quarters = self._get_quarters(min_date, max_date)
            
            out_df = pd.DataFrame(columns = self._out_score_cols)
            for quarter in quarters:
                self._log('{} {} {}'.format(quarter[0].strftime('%Y-%m-%d'), quarter[1].strftime('%Y-%m-%d'), quarter[2]))
                out_df = out_df.append(self._get_all_score(quarter = quarter))
        else:
            out_df = self._get_all_score()
        # 出力            
        self._out_sec_score(out_df)
        
