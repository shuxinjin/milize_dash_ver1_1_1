#!/bin/bash

#Name        : PDF_txt_Converter.sh
#Purpose     : PDFファイルのテキスト変換
#Created Date: 2018.08.08
#Created by  : Wenfeng Huang (MILIZE Inc.)
#Updated Date: 2018.08.08
#Updated by  : Wenfeng Huang (MILIZE Inc.)

baseDir=`pwd`/../../01_TextMining_Files
# Folder structure:
# 01_TextMining_Files
#     01_Input
#           SMBC
#               *.pdf
#           SMBC_Credit
#               *.pdf
#           野村證券
#               *.pdf
#
#     02_Out_PDF_text
#           自動生成...

inDir=${baseDir}/01_Input/野村證券
outDir=${baseDir}/02_Out_PDF_text

# get the first day of the last month as the start date to convert
# if a file already converted, skip it.

time_check_file=./time_check
if [ ! -f $time_check_file ]; then
    latest_time=`date -d "50 years ago" "+%Y-%m-01 00:00:00"`
else
    latest_time=`ls --full-time ${time_check_file} | awk '{print $6,$7;}'`
fi
echo latest=${latest_time}

# convert the PDF file recursively, saving the text file to the folder '/YYYY/YYYY-MM'
find $inDir -type f -name '*.pdf' -newermt "${latest_time}" | while read FILE; do
    file_date=`ls --full-time ${FILE} | awk '{print $6,$7;}'`
    folder=${file_date:0:4}/${file_date:0:7}
    out_d=$outDir/$folder
    f_base_name=$(basename ${FILE})
    out_f=${out_d}/${f_base_name%.pdf}.txt
    if [ ! -f "${out_f}" ]; then
        if [ ! -d "${out_d}" ]; then
            mkdir -p "${out_d}"
        fi
        echo "Convert: " ${FILE}
        pdftotext "${FILE}" "${out_f}"
    fi
done && touch ${time_check_file}

# update the time stamp
