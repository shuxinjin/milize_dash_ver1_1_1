# coding: utf-8
'''
Name        : vectorize.py
Purpose     : アナリストレポートのテキストからベクトル化する
Created Date: 2018.08.10
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.08.10
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''
import sys
sys.path.append('./A02_Cleansing')
sys.path.append('./A03_Return_Match')
sys.path.append('./A04_Scoring')
sys.path.append('./A50_Config')
sys.path.append('./A90_utils')

import argparse
    
import datetime
from   dateutil.relativedelta            import relativedelta
import os
import re

from   A02_Cleansing.cleansing           import cleansing
from   A02_Cleansing.get_broker          import get_broker
from   A02_Cleansing.get_report_items    import get_report_items
from   A04_Scoring.text_summary          import text_summary
from   A04_Scoring.text_token            import text_token
from   A04_Scoring.text_vector           import text_vector
from   A50_Config.config_roll            import date_settings
from   A50_Config.config_roll            import doc_clustering
from   A50_Config.config_roll            import file_names
from   A50_Config.config_roll            import flags
from   A50_Config.config_roll            import roll
from   A90_utils.m_txtm_base             import m_txtm_base

class run_all(m_txtm_base):

    _log_dir = '../log/current_roll/all_steps'
    _log_prefix = 't_roll'

    def _search_text_dir(self, root_text_dir, str_month):
        '''
        テキスト格納フォルダ確定
        '''
        text_dirs = []
        for root, dirs, files in os.walk(root_text_dir):
            for d in dirs:
                if len(d) == 7 and d >= str_month:
                    text_dirs.append(os.path.join(root, d))
        return text_dirs
    
    def main(self, start_date, end_date = None):
        
        if end_date is None:
            end_date = datetime.datetime.now()
            
        end_month = end_date.strftime('%Y-%m')
        str_month = start_date.strftime('%Y-%m')
        self._log('Start Month: {}, End Month: {}'.format(str_month, end_month))
        self._log('ROLL_WINDOW: {}M_{}M, Doc Cluster: {}'.format(roll.ROLL_WINDOW, roll.ROLL_STEP_LEN, doc_clustering.doc_cluster))
        
        while str_month <= end_month:
            self._log('Month: {}'.format(str_month))
            str_year = start_date.strftime('%Y')
            text_dirs = self._search_text_dir(file_names.TEXT_HOME_DIR, str_month)
            report_broker_file = re.sub('.csv', '_{}.csv'.format(str_month), file_names.RECORD_BROKERS)
            out_broker_file = '{}/{}/{}/{}'.format(file_names.META_DIR, str_year, str_month, report_broker_file)
#            print('text_dir =', text_dir)
    
            # 発行体判別
            self._log('発行体判別開始...')
            self._log(text_dirs)
            self._log(out_broker_file)
            with get_broker(self._logger) as b:
                b.main(text_dirs, out_broker_file)
            self._log('発行体判別終了...')
            self._log('')
            
            # 銘柄レポートを対象に、銘柄コード・レポート日付抽出
            report_item_file = re.sub('.csv', '_{}.csv'.format(str_month), file_names.RECORD_ITEMS)
            out_report_item_file = '{}/{}/{}/{}'.format(file_names.META_DIR, str_year, str_month, report_item_file)
            self._log('項目抽出開始...')
            self._log(out_broker_file)
            with get_report_items(self._logger) as r:
                r.main(out_broker_file, out_report_item_file)
            self._log('項目抽出終了...')
            self._log('')
            
            # 銘柄レポートを対象に、発行体ごとにクレンジング実施
            self._log('クレンジング開始...')
            with cleansing(self._logger) as c:
                c.main(out_broker_file)
            self._log('クレンジング終了...')
            
            month_start = datetime.date(start_date.year, start_date.month, 1)
            next_month = month_start + relativedelta(months = 1)
            month_end = next_month + relativedelta(days = -1)
            
            # テキストのトーケン分割
            self._log('テキストのトーケン分割開始...')
            train_start = month_start + relativedelta(months = -roll.ROLL_WINDOW)
            train_end = month_start + relativedelta(days = -1)
            pred_end = month_end
            with text_token(train_start, train_end, pred_end, self._logger) as tt:
                tt.main(out_report_item_file)
            self._log('テキストのトーケン分割終了...')
        
            # 文書の要約作成
            self._log('テキストの要約作成開始...')
            with text_summary(train_start, train_end, pred_end, self._logger) as ts:
                ts.main(out_report_item_file)
            self._log('テキストの要約作成終了...')

            # トーケンによるテキストのベクトル化
            self._log('テキストのベクトル化開始...')
            with text_vector(train_start, train_end, pred_end, self._logger) as tvt:
                tvt.main(out_report_item_file, create_flg = flags.create_flg_vectorizing)
            self._log('テキストのベクトル化終了...')
            
            start_date += relativedelta(months = 1)
            str_month = start_date.strftime('%Y-%m')
        
if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument('-s', '--start_date', default = None, required = False)
    parser.add_argument('-e', '--end_date', default = None, required = False)

    args = parser.parse_args()
    
    start_date = None if args.start_date is None else datetime.datetime.strptime(args.start_date, '%Y/%m/%d')
    end_date   = None if args.end_date is None else datetime.datetime.strptime(args.end_date, '%Y/%m/%d')
    
    if start_date is None and end_date is None:
        start_date = date_settings.START_DATE
        end_date   = date_settings.END_DATE
    else:
        current_date = datetime.datetime.now()
        if start_date is None:
            month_start  = datetime.datetime(current_date.year, current_date.month, 1)
            start_date = month_start
        if end_date is None:
            end_date   = current_date

    with run_all() as ra:
        ra.main(start_date, end_date)
