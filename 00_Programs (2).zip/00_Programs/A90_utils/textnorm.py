# -*- coding: utf-8 -*-
'''
Name        : textnorm.py
Purpose     : テキストの正規化処理
Created Date: 2018.08.03
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.08.03
Updated by  : Wenfeng Huang (MILIZE Inc.)
Descriptions:
    URL:
    https://github.com/neologd/mecab-ipadic-neologd/wiki/Regexp.ja
    
    生成時には色々置換と削除をしているが、最後に反映されているのは以下である。
    
    全角英数字は半角に置換
    
    ０-９=> 0-9
    Ａ-Ｚ=> A-Z
    ａ-ｚ=> a-z
    半角カタカナは全角に置換
    
    半角の濁音と半濁音の記号が1文字扱いになってるので気をつけること。
    
    ハイフンマイナスっぽい文字を置換
    
    以下はハイフンマイナスに置換する。
    
    MODIFIER LETTER MINUS SIGN(U+02D7)
    ARMENIAN HYPHEN(U+058A)
    ハイフン(U+2010)
    ノンブレーキングハイフン(U+2011)
    フィギュアダッシュ(U+2012)
    エヌダッシュ(U+2013)
    Hyphen bullet(U+2043)
    上付きマイナス(U+207B)
    下付きマイナス(U+208B)
    負符号(U+2212)
    長音記号っぽい文字を置換
    
    以下は全角長音記号に置換する。
    
    エムダッシュ(U+2014)
    ホリゾンタルバー(U+2015)
    横細罫線(U+2500)
    横太罫線(横太罫線)
    SMALL HYPHEN-MINUS(U+FE63)
    全角ハイフンマイナス(U+FF0D)
    半角長音記号(U+FF70)
    1回以上連続する長音記号は1回に置換
    
    連続したら削除する。
    
    スーーーーーーパーーーーーー => スーパー
    チルダっぽい文字は削除
    
    以下は削除する。
    
    半角チルダ
    チルダ演算子
    INVERTED LAZY S
    波ダッシュ
    WAVY DASH
    全角チルダ ⇒　保留
    以下の全角記号は半角記号に置換
    
    /！”＃＄％＆’（）＊＋，−．／：；＜＞？＠［￥］＾＿｀｛｜｝
    以下の半角記号は全角記号に置換
    
    ｡､･=｢｣
    中黒とイコールは人名によく使われるので、半角にするのが難しい。
    カギ括弧はおもに全角が使われる
    全角スペースは半角スペースに置換
    
    '　' => ' '
    1つ以上の半角スペースは、1つの半角スペースに置換
    
    ' ' => ' '
    解析対象テキストの先頭と末尾の半角スペースは削除
    
    ' テキストの前' => 'テキストの前'
    'テキストの後 ' => 'テキストの後'
    「ひらがな・全角カタカナ・半角カタカナ・漢字・全角記号」間に含まれる半角スペースは削除
    
    検索 エンジン 自作 入門 を 買い ました ！！！ => 検索エンジン自作入門を買いました！！！
    Coding the Matrix => Coding the Matrix
    「ひらがな・全角カタカナ・半角カタカナ・漢字・全角記号」と「半角英数字」の間に含まれる半角スペースは削除
    
    アルゴリズム C => アルゴリズムC
    Algorithm C => Algorithm C

'''

import re
import unicodedata

def _unicode_normalize(cls, s):
    pt = re.compile('([{}]+)'.format(cls))

    def norm(c):
        return unicodedata.normalize('NFKC', c) if pt.match(c) else c

    s = ''.join(norm(x) for x in re.split(pt, s))
    s = re.sub('－', '-', s)
    return s

def _remove_extra_spaces(s):
    s = re.sub('[ 　]+', ' ', s)
    blocks = ''.join(('\u4E00-\u9FFF',  # CJK UNIFIED IDEOGRAPHS
                      '\u3040-\u309F',  # HIRAGANA
                      '\u30A0-\u30FF',  # KATAKANA
                      '\u3000-\u303F',  # CJK SYMBOLS AND PUNCTUATION
                      '\uFF00-\uFFEF',   # HALFWIDTH AND FULLWIDTH FORMS
                      ))
    basic_latin = '\u0000-\u007F'

    def remove_space_between(cls1, cls2, s):
        p = re.compile('([{}]) ([{}])'.format(cls1, cls2))
        while p.search(s):
            s = p.sub(r'\1\2', s)
        return s

    s = remove_space_between(blocks, blocks, s)
    s = remove_space_between(blocks, basic_latin, s)
    s = remove_space_between(basic_latin, blocks, s)

    return s

def normalize_neologd(s, encoding = None):
    s = s.strip()
    s = _unicode_normalize('０-９Ａ-Ｚａ-ｚ｡-ﾟ', s)

    def maketrans(f, t):
        return {ord(x): ord(y) for x, y in zip(f, t)}

    s = re.sub('[˗֊‐‑‒–⁃⁻₋−]+', '-', s)  # normalize hyphens
    s = re.sub('[﹣－ｰ—―─━ー]+', 'ー', s)  # normalize choonpus
    #s = re.sub('[~∼∾〜〰～]', '', s)  # remove tildes
    s = re.sub('[~∼∾〜〰]', '', s)  # remove tildes
    s = s.translate(
        maketrans('!"#$%&\'()*+,-./:;<=>?@[¥]^_`{|}~｡､･｢｣',
              '！”＃＄％＆’（）＊＋，－．／：；＜＝＞？＠［￥］＾＿｀｛｜｝〜。、・「」'))

    s = _remove_extra_spaces(s)
    s = _unicode_normalize('！”＃＄％＆’（）＊＋，－．／：；＜＞？＠［￥］＾＿｀｛｜｝〜', s)  # keep ＝,・,「,」
    s = re.sub('[’]', '\'', s)
    s = re.sub('[”]', '"', s)

    return s
    
    
from chardet.universaldetector import UniversalDetector
    
def detect_encode(filename):
    '''
    ファイルのエンコード判定
    '''
    detector = UniversalDetector()
    try:
        with open(filename, mode = 'rb') as f:
            for l in f:
                detector.feed(l)
                if detector.done:
                    break
    finally:
        detector.close()
    return detector.result['encoding']
