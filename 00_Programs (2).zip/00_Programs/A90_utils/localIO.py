# -*- coding: utf-8 -*-
'''
Name        : localIO.py
Purpose     : 入出力関連の共通メソッド
Created Date: 2018.08.03
Created by  : Wenfeng Huang (MILIZE Inc.)
Updated Date: 2018.08.03
Updated by  : Wenfeng Huang (MILIZE Inc.)
'''

import os
import re

def get_dirlist(dir_path):
    # 配下のフォルダ一覧取得
    dirs = os.listdir(dir_path)
    if dirs is None or len(dirs) == 0:
        return None
    else:
        filter_f = lambda x : os.path.isdir(os.path.join(dir_path, x))
        return sorted(list(filter(filter_f, dirs)))

def get_fullpath_dirlist(dir_path):
    # 配下のフォルダ一覧取得し、フルパスの形式で戻す
    
    dirs = [os.path.join(dir_path, x) for x in os.listdir(dir_path)] 
    if dirs is None or len(dirs) == 0:
        return None
    else:
        filter_f = lambda x : os.path.isdir(x)
        return sorted(list(filter(filter_f, dirs)))

def get_filelist(dir_path, ext = None):
    # 配下のファイル一覧取得。拡張子指定可能
    
    files = os.listdir(dir_path)
    if files is None or len(files) == 0:
        return None
    else:
        if ext is None:
            filter_f = lambda x: os.path.isfile(os.path.join(dir_path, x))
        else:
            filter_f = lambda x: os.path.isfile(os.path.join(dir_path, x)) \
                       and re.match(ext, os.path.splitext(x)[-1], re.IGNORECASE)
        return sorted(list(filter(filter_f, files)))

def get_fullpath_filelist(dir_path, ext = None):
    # 配下のファイル一覧取得し、フルパスの形式で戻す。拡張子指定可能
    
    files = [os.path.join(dir_path, x) for x in os.listdir(dir_path)]
    if files is None or len(files) == 0:
        return None
    else:
        if ext is None:
            filter_f = lambda x: os.path.isfile(x)
        else:
            filter_f = lambda x: os.path.isfile(x) \
                       and re.match(ext, os.path.splitext(x)[1], re.IGNORECASE)
        return sorted(list(filter(filter_f, files)))

def get_io_subdirs(dir_path_in, dir_path_out):
    # 配下のフォルダ一覧取得し、出力フォルダに同じ構造を複製
    sub_dirs = get_dirlist(dir_path_in)
    if sub_dirs is None:
        return None
    else:
        f = lambda x: (os.path.join(dir_path_in, x), os.path.join(dir_path_out, x))
        return [f(sub_dir) for sub_dir in sub_dirs]

def create_outdir(out_file):
    # 出力ファイルのフォルダを作成
    if out_file is not None:
        out_path = os.path.dirname(out_file)
        if not os.path.exists(out_path):
            os.makedirs(out_path)

def create_empty_file(file_name):
    # 空の出力ファイル作成
    
    create_outdir(file_name)
    with open(file_name, 'w'):
        pass

def is_existing(file_name):
    # ファイルの存在チェック
    return os.path.exists(file_name)